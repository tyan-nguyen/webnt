-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jan 17, 2024 at 03:53 AM
-- Server version: 5.7.40
-- PHP Version: 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fulladmin`
--

-- --------------------------------------------------------

--
-- Table structure for table `auth_assignment`
--

DROP TABLE IF EXISTS `auth_assignment`;
CREATE TABLE IF NOT EXISTS `auth_assignment` (
  `item_name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`item_name`,`user_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `auth_assignment`
--

INSERT INTO `auth_assignment` (`item_name`, `user_id`, `created_at`) VALUES
('Admin', 1, 1556454369),
('bientapvien', 1, 1570155479),
('Default', 1, 1556454369),
('thongketruycap', 1, 1687142184);

-- --------------------------------------------------------

--
-- Table structure for table `auth_item`
--

DROP TABLE IF EXISTS `auth_item`;
CREATE TABLE IF NOT EXISTS `auth_item` (
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `rule_name` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `data` text COLLATE utf8_unicode_ci,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `group_code` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `rule_name` (`rule_name`),
  KEY `idx-auth_item-type` (`type`),
  KEY `fk_auth_item_group_code` (`group_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `auth_item`
--

INSERT INTO `auth_item` (`name`, `type`, `description`, `rule_name`, `data`, `created_at`, `updated_at`, `group_code`) VALUES
('/*', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/admin/*', 3, NULL, NULL, NULL, 1555604426, 1555604426, NULL),
('/admin/catelogies/*', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/catelogies/bulk-delete', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/catelogies/create', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/catelogies/delete', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/catelogies/index', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/catelogies/update', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/catelogies/view', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/default/*', 3, NULL, NULL, NULL, 1570283031, 1570283031, NULL),
('/admin/default/index', 3, NULL, NULL, NULL, 1570283031, 1570283031, NULL),
('/admin/links/*', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/links/bulk-delete', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/links/create', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/links/delete', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/links/index', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/links/update', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/links/view', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/news/*', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/news/bulk-delete', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/news/create', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/news/del-folder-not-used', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/news/delete', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/news/index', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/news/update', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/news/view', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/settings/*', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/settings/bulk-delete', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/settings/create', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/settings/delete', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/settings/index', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/settings/update', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/settings/view', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/socials/*', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/socials/bulk-delete', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/socials/create', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/socials/delete', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/socials/index', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/socials/update', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/socials/view', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/admin/thong-ke-truy-cap/*', 3, NULL, NULL, NULL, 1586086805, 1586086805, NULL),
('/admin/thong-ke-truy-cap/bulk-delete', 3, NULL, NULL, NULL, 1586086805, 1586086805, NULL),
('/admin/thong-ke-truy-cap/create', 3, NULL, NULL, NULL, 1586086805, 1586086805, NULL),
('/admin/thong-ke-truy-cap/delete', 3, NULL, NULL, NULL, 1586086805, 1586086805, NULL),
('/admin/thong-ke-truy-cap/index', 3, NULL, NULL, NULL, 1586086805, 1586086805, NULL),
('/admin/thong-ke-truy-cap/update', 3, NULL, NULL, NULL, 1586086805, 1586086805, NULL),
('/admin/thong-ke-truy-cap/view', 3, NULL, NULL, NULL, 1586086805, 1586086805, NULL),
('/gii/*', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/gii/default/*', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/gii/default/action', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/gii/default/diff', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/gii/default/index', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/gii/default/preview', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/gii/default/view', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/gridview/*', 3, NULL, NULL, NULL, 1570121547, 1570121547, NULL),
('/gridview/export/*', 3, NULL, NULL, NULL, 1570121547, 1570121547, NULL),
('/gridview/export/download', 3, NULL, NULL, NULL, 1570121547, 1570121547, NULL),
('/page/*', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/page/about-us', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/page/captcha', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/page/contact', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/site/*', 3, NULL, NULL, NULL, 1555604424, 1555604424, NULL),
('/site/cat', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/site/index', 3, NULL, NULL, NULL, 1555604425, 1555604425, NULL),
('/site/news', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/site/newsletter', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/site/not-found', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/site/search', 3, NULL, NULL, NULL, 1664291122, 1664291122, NULL),
('/user-management/*', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth-item-group/*', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth-item-group/bulk-activate', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth-item-group/bulk-deactivate', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth-item-group/bulk-delete', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth-item-group/create', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth-item-group/delete', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth-item-group/grid-page-size', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth-item-group/grid-sort', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth-item-group/index', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth-item-group/toggle-attribute', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth-item-group/update', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth-item-group/view', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth/*', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth/captcha', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth/change-own-password', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth/confirm-email', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth/confirm-email-receive', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth/confirm-registration-email', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth/login', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth/logout', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth/password-recovery', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth/password-recovery-receive', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/auth/registration', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/permission/*', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/permission/bulk-activate', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/permission/bulk-deactivate', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/permission/bulk-delete', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/permission/create', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/permission/delete', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/permission/grid-page-size', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/permission/grid-sort', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/permission/index', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/permission/refresh-routes', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/permission/set-child-permissions', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/permission/set-child-routes', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/permission/toggle-attribute', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/permission/update', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/permission/view', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/role/*', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/role/bulk-activate', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/role/bulk-deactivate', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/role/bulk-delete', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/role/create', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/role/delete', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/role/grid-page-size', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/role/grid-sort', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/role/index', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/role/set-child-permissions', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/role/set-child-roles', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/role/toggle-attribute', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/role/update', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/role/view', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user-permission/*', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user-permission/set', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user-permission/set-roles', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user-visit-log/*', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user-visit-log/bulk-activate', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user-visit-log/bulk-deactivate', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user-visit-log/bulk-delete', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user-visit-log/create', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user-visit-log/delete', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user-visit-log/grid-page-size', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user-visit-log/grid-sort', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user-visit-log/index', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user-visit-log/toggle-attribute', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user-visit-log/update', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user-visit-log/view', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user/*', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user/bulk-activate', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user/bulk-deactivate', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user/bulk-delete', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user/change-password', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user/create', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user/delete', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user/grid-page-size', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user/grid-sort', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user/index', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user/toggle-attribute', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user/update', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('/user-management/user/view', 3, NULL, NULL, NULL, 1426062189, 1426062189, NULL),
('Admin', 1, 'Admin', NULL, NULL, 1426062189, 1426062189, NULL),
('assignRolesToUsers', 2, 'Assign roles to users', NULL, NULL, 1426062189, 1426062189, 'userManagement'),
('bientapvien', 1, 'Biên tập viên', NULL, NULL, 1570120917, 1570120917, NULL),
('bindUserToIp', 2, 'Bind user to IP', NULL, NULL, 1426062189, 1426062189, 'userManagement'),
('cauhinh', 2, 'Cấu hình', NULL, NULL, 1570156160, 1570156160, 'userCommonPermissions'),
('changeOwnPassword', 2, 'Change own password', NULL, NULL, 1426062189, 1426062189, 'userCommonPermissions'),
('changeUserPassword', 2, 'Change user password', NULL, NULL, 1426062189, 1426062189, 'userManagement'),
('commonPermission', 2, 'Common permission', NULL, NULL, 1426062188, 1426062188, NULL),
('createUsers', 2, 'Create users', NULL, NULL, 1426062189, 1426062189, 'userManagement'),
('dangtin', 2, 'Đăng tin', NULL, NULL, 1570156034, 1570156034, 'userCommonPermissions'),
('Default', 1, 'Default', NULL, NULL, 1555604497, 1555604497, NULL),
('deleteUsers', 2, 'Delete users', NULL, NULL, 1426062189, 1426062189, 'userManagement'),
('duyettin', 1, 'Duyệt tin', NULL, NULL, 1570120962, 1570120962, NULL),
('editUserEmail', 2, 'Edit user email', NULL, NULL, 1426062189, 1426062189, 'userManagement'),
('editUsers', 2, 'Edit users', NULL, NULL, 1426062189, 1426062189, 'userManagement'),
('per_dashboard', 2, 'Access Dashboard', NULL, NULL, 1664291118, 1664291118, 'userManagement'),
('permission_thongketruycap', 2, 'Thống kê truy cập', NULL, NULL, 1586086798, 1586086798, 'userCommonPermissions'),
('qltaikhoan', 2, 'Quản lý tài khoản', NULL, NULL, 1570156229, 1570156229, 'userManagement'),
('thongketruycap', 1, 'Thống kê truy cập', NULL, NULL, 1586086766, 1586086766, NULL),
('truycaptrangadmin', 2, 'Truy cập trang admin', NULL, NULL, 1570121444, 1570121444, 'userCommonPermissions'),
('user-default', 2, 'user-default', NULL, NULL, 1555604419, 1555604419, 'userCommonPermissions'),
('viewRegistrationIp', 2, 'View registration IP', NULL, NULL, 1426062189, 1426062189, 'userManagement'),
('viewUserEmail', 2, 'View user email', NULL, NULL, 1426062189, 1426062189, 'userManagement'),
('viewUserRoles', 2, 'View user roles', NULL, NULL, 1426062189, 1426062189, 'userManagement'),
('viewUsers', 2, 'View users', NULL, NULL, 1426062189, 1426062189, 'userManagement'),
('viewVisitLog', 2, 'View visit log', NULL, NULL, 1426062189, 1426062189, 'userManagement');

-- --------------------------------------------------------

--
-- Table structure for table `auth_item_child`
--

DROP TABLE IF EXISTS `auth_item_child`;
CREATE TABLE IF NOT EXISTS `auth_item_child` (
  `parent` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `child` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`parent`,`child`),
  KEY `child` (`child`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `auth_item_child`
--

INSERT INTO `auth_item_child` (`parent`, `child`) VALUES
('per_dashboard', '/admin/*'),
('per_dashboard', '/admin/catelogies/*'),
('per_dashboard', '/admin/default/*'),
('truycaptrangadmin', '/admin/default/*'),
('user-default', '/admin/default/*'),
('user-default', '/admin/default/index'),
('per_dashboard', '/admin/links/*'),
('per_dashboard', '/admin/news/*'),
('per_dashboard', '/admin/settings/*'),
('per_dashboard', '/admin/socials/*'),
('per_dashboard', '/admin/thong-ke-truy-cap/*'),
('permission_thongketruycap', '/admin/thong-ke-truy-cap/*'),
('user-default', '/site/*'),
('qltaikhoan', '/user-management/*'),
('changeOwnPassword', '/user-management/auth/change-own-password'),
('assignRolesToUsers', '/user-management/user-permission/set'),
('assignRolesToUsers', '/user-management/user-permission/set-roles'),
('viewVisitLog', '/user-management/user-visit-log/grid-page-size'),
('viewVisitLog', '/user-management/user-visit-log/index'),
('viewVisitLog', '/user-management/user-visit-log/view'),
('editUsers', '/user-management/user/bulk-activate'),
('editUsers', '/user-management/user/bulk-deactivate'),
('deleteUsers', '/user-management/user/bulk-delete'),
('changeUserPassword', '/user-management/user/change-password'),
('createUsers', '/user-management/user/create'),
('deleteUsers', '/user-management/user/delete'),
('viewUsers', '/user-management/user/grid-page-size'),
('viewUsers', '/user-management/user/index'),
('editUsers', '/user-management/user/update'),
('viewUsers', '/user-management/user/view'),
('Admin', 'assignRolesToUsers'),
('Admin', 'cauhinh'),
('Admin', 'changeOwnPassword'),
('bientapvien', 'changeOwnPassword'),
('duyettin', 'changeOwnPassword'),
('user-default', 'changeOwnPassword'),
('Admin', 'changeUserPassword'),
('Admin', 'createUsers'),
('Admin', 'dangtin'),
('bientapvien', 'dangtin'),
('duyettin', 'dangtin'),
('Admin', 'deleteUsers'),
('Admin', 'editUsers'),
('bientapvien', 'per_dashboard'),
('thongketruycap', 'permission_thongketruycap'),
('Admin', 'qltaikhoan'),
('Default', 'thongketruycap'),
('Admin', 'truycaptrangadmin'),
('bientapvien', 'truycaptrangadmin'),
('Default', 'truycaptrangadmin'),
('duyettin', 'truycaptrangadmin'),
('Admin', 'user-default'),
('bientapvien', 'user-default'),
('Default', 'user-default'),
('duyettin', 'user-default'),
('editUserEmail', 'viewUserEmail'),
('assignRolesToUsers', 'viewUserRoles'),
('Admin', 'viewUsers'),
('assignRolesToUsers', 'viewUsers'),
('changeUserPassword', 'viewUsers'),
('createUsers', 'viewUsers'),
('deleteUsers', 'viewUsers'),
('editUsers', 'viewUsers');

-- --------------------------------------------------------

--
-- Table structure for table `auth_item_group`
--

DROP TABLE IF EXISTS `auth_item_group`;
CREATE TABLE IF NOT EXISTS `auth_item_group` (
  `code` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `auth_item_group`
--

INSERT INTO `auth_item_group` (`code`, `name`, `created_at`, `updated_at`) VALUES
('userCommonPermissions', 'User common permission', 1426062189, 1426062189),
('userManagement', 'User management', 1426062189, 1426062189);

-- --------------------------------------------------------

--
-- Table structure for table `auth_rule`
--

DROP TABLE IF EXISTS `auth_rule`;
CREATE TABLE IF NOT EXISTS `auth_rule` (
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `data` text COLLATE utf8_unicode_ci,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `blocks`
--

DROP TABLE IF EXISTS `blocks`;
CREATE TABLE IF NOT EXISTS `blocks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `content` text COLLATE utf8_unicode_ci,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `links`
--

DROP TABLE IF EXISTS `links`;
CREATE TABLE IF NOT EXISTS `links` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `name_en` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `link` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `link_en` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `open_new_tab` tinyint(1) NOT NULL,
  `priority` tinyint(1) NOT NULL,
  `type` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `links`
--

INSERT INTO `links` (`id`, `name`, `name_en`, `link`, `link_en`, `open_new_tab`, `priority`, `type`) VALUES
(1, 'Trang chủ', 'Home', '/', '/', 0, 1, 'MENU_TOP'),
(2, 'Giới thiệu', 'About', '/about', '/about', 0, 2, 'MENU_TOP'),
(3, 'Sản phẩm', 'Products', '/products', '/products', 0, 3, 'MENU_TOP'),
(5, 'Liên hệ', 'Contact', '/contact', '/contact', 0, 6, 'MENU_TOP'),
(6, 'Trang chủ', 'Home', '/', '/', 0, 1, 'QUICK_LINK'),
(7, 'Giới thiệu', 'About us', '/about', '/about', 0, 1, 'QUICK_LINK'),
(8, 'Sản phẩm', 'Product', '/products', '/products', 0, 1, 'QUICK_LINK'),
(9, 'Blogs', 'Blogs', '/blog', '/blog', 0, 1, 'QUICK_LINK'),
(10, 'Liên hệ', 'Contact', '/contact', '/contact', 0, 1, 'QUICK_LINK'),
(11, 'Chi nhánh toàn cầu', 'Global Presence', '/global-presence', '/global-presence', 0, 1, 'POPULAR_LINK'),
(12, '<i class=\"fab fa-twitter fw-normal\"></i>', '<i class=\"fab fa-twitter fw-normal\"></i>', '#', '#', 1, 1, 'SOCIAL_LINK'),
(13, '<i class=\"fab fa-facebook-f fw-normal\"></i>', '<i class=\"fab fa-facebook-f fw-normal\"></i>', '#', '#', 1, 1, 'SOCIAL_LINK'),
(14, '<i class=\"fab fa-linkedin-in fw-normal\"></i>', '<i class=\"fab fa-linkedin-in fw-normal\"></i>', '#', '#', 1, 1, 'SOCIAL_LINK'),
(15, '<i class=\"fab fa-instagram fw-normal\"></i>', '<i class=\"fab fa-instagram fw-normal\"></i>', '#', '#', 1, 1, 'SOCIAL_LINK'),
(16, 'Giá trị bền vững', 'Sustainability', '/sustainability', '/sustainability', 0, 2, 'POPULAR_LINK'),
(19, 'Chi nhánh toàn cầu', 'Global Presence', '/global-presence', '/global-presence', 0, 4, 'MENU_TOP'),
(20, 'Bài viết', 'Blogs', '/blog', '/blog', 0, 5, 'MENU_TOP');

-- --------------------------------------------------------

--
-- Table structure for table `migration`
--

DROP TABLE IF EXISTS `migration`;
CREATE TABLE IF NOT EXISTS `migration` (
  `version` varchar(180) COLLATE utf8_unicode_ci NOT NULL,
  `apply_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `migration`
--

INSERT INTO `migration` (`version`, `apply_time`) VALUES
('m000000_000000_base', 1480859869),
('m140209_132017_init', 1480859873),
('m140403_174025_create_account_table', 1480859874),
('m140504_113157_update_tables', 1480859876),
('m140504_130429_create_token_table', 1480859876),
('m140506_102106_rbac_init', 1480867652),
('m140830_171933_fix_ip_field', 1480859877),
('m140830_172703_change_account_table_name', 1480859877),
('m141222_110026_update_ip_field', 1480859877),
('m141222_135246_alter_username_length', 1480859877),
('m150425_012013_init', 1570158165),
('m150425_082737_redirects', 1570158165),
('m150614_103145_update_social_account_table', 1480859878),
('m150623_212711_fix_username_notnull', 1480859878),
('m151218_234654_add_timezone_to_profile', 1480859878);

-- --------------------------------------------------------

--
-- Table structure for table `newsletter`
--

DROP TABLE IF EXISTS `newsletter`;
CREATE TABLE IF NOT EXISTS `newsletter` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `site` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `date_created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `newsletter`
--

INSERT INTO `newsletter` (`id`, `email`, `site`, `date_created`) VALUES
(16, 'thaipn@bachthuanan.com', 'localhost', '2023-09-19 14:09:04'),
(17, 'bouongsting@gmail.com', 'localhost', '2023-09-27 15:09:24');

-- --------------------------------------------------------

--
-- Table structure for table `news_catelogies`
--

DROP TABLE IF EXISTS `news_catelogies`;
CREATE TABLE IF NOT EXISTS `news_catelogies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cover` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `pid` int(11) DEFAULT NULL,
  `priority` tinyint(4) DEFAULT NULL,
  `level` tinyint(4) DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `content` text COLLATE utf8_unicode_ci,
  `seo_title` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_description` text COLLATE utf8_unicode_ci,
  `seo_image` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lang` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `code` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `news_catelogies`
--

INSERT INTO `news_catelogies` (`id`, `cover`, `name`, `slug`, `pid`, `priority`, `level`, `description`, `content`, `seo_title`, `seo_description`, `seo_image`, `lang`, `code`, `status`, `date_created`, `user_created`) VALUES
(17, 'http://localhost:9999/images/posts/_categories/61lgwt/post1.jpg', 'Tin tức', 'tin-tuc', 0, 1, 1, '', '<p><img src=\"/images/posts/_categories/61lgwt/1.png\" alt=\"1\" /> x</p>', '', '', NULL, 'vi', '61lgwt', 'PUBLISH', '2024-01-12 06:07:14', 1),
(18, NULL, 'Thông báo', 'thong-bao', 0, 2, 1, NULL, NULL, '', '', NULL, 'vi', '20axdt', NULL, NULL, NULL),
(21, NULL, 'abc', 'abc', 0, NULL, 1, NULL, NULL, '', '', NULL, 'vi', '81owra', NULL, NULL, NULL),
(22, NULL, '77', '77', 0, NULL, 1, NULL, NULL, '', '', NULL, 'vi', '51ards', NULL, NULL, NULL),
(23, NULL, 'ssss', 'ssss', 0, NULL, 1, NULL, NULL, '', '', NULL, 'vi', '88idkt', NULL, NULL, NULL),
(24, NULL, 'sssxxxx', 'sssxxxx', 17, NULL, 2, NULL, NULL, '', '', NULL, 'vi', '89estj', NULL, NULL, NULL),
(25, NULL, 'csfcxsfadsf', 'cccccccccccc', 0, NULL, 1, NULL, NULL, '', '', NULL, 'vi', '3OKky', NULL, NULL, NULL),
(26, NULL, 'dsafasddfasf', 'dsafasddfasf', 0, NULL, 1, NULL, NULL, '', '', NULL, 'vi', '364md7', NULL, NULL, NULL),
(27, NULL, 'yiytiyuiy', 'yiytiyuiy', 0, NULL, 1, NULL, NULL, '', '', NULL, 'vi', '94aqwr', NULL, NULL, NULL),
(28, NULL, 'this is english', 'this-is-english', 0, NULL, 1, NULL, NULL, '', '', NULL, 'en', '61lgwt', NULL, NULL, NULL),
(29, NULL, 'cccccccccccc', 'cccccccccccc', 0, NULL, 1, NULL, NULL, '', '', NULL, 'en', '3OKky', NULL, NULL, NULL),
(30, NULL, 'zz', 'zz', 23, NULL, 2, NULL, NULL, '', '', NULL, 'vi', '19becm', NULL, NULL, NULL),
(31, NULL, 'ggggg', 'ggggg', 0, NULL, 1, NULL, NULL, '', '', NULL, 'en', '39arqg', NULL, NULL, NULL),
(32, NULL, '11', '11', 0, NULL, 1, NULL, NULL, '', '', NULL, 'vi', '39arqg', NULL, NULL, NULL),
(33, NULL, '99', '99', 23, NULL, 2, NULL, NULL, '', '', NULL, 'vi', '97yhem', NULL, NULL, NULL),
(34, '', 'xxxxxxx', 'xxxxxxx', 0, NULL, 1, '', '', '', '', NULL, 'khmer', '61lgwt', 'DRAFT', '2024-01-12 16:04:39', 1),
(35, NULL, 'New Category Title Here...', 'new-category-title-here', 0, NULL, 1, NULL, NULL, NULL, NULL, NULL, 'vi', '68puzb', NULL, NULL, NULL),
(36, NULL, 'New Category Title Here...', 'temp', 0, NULL, 1, NULL, NULL, NULL, NULL, NULL, 'vi', '33wpjq', NULL, NULL, NULL),
(37, NULL, 'New Category Title Here...', 'temp', 0, NULL, 1, NULL, NULL, NULL, NULL, NULL, 'vi', '32cnut', NULL, NULL, NULL),
(38, 'http://localhost:9999/images/posts/_categories/97oeak/post3.jpg', 'sssss', 'temp', 0, NULL, 1, '', '', '', '', 'http://localhost:9999/images/posts/_categories/97oeak/post2.jpg', 'vi', '97oeak', 'DRAFT', '2024-01-13 14:34:53', 1),
(39, NULL, 'New Category Title Here...', 'temp', 0, NULL, 1, '', NULL, '', '', NULL, 'vi', '73ewpx', 'HIDE', '2024-01-12 15:08:19', 1),
(40, NULL, 'New Category Title Here...', 'temp', 0, NULL, 1, '', NULL, '', '', NULL, 'vi', '90gvyx', 'DRAFT', '2024-01-13 09:20:09', 1),
(41, '', 'New Category Title Here...', 'temp', 0, NULL, 1, '', '', '', '', NULL, 'vi', '51lizj', 'DRAFT', '2024-01-12 14:12:47', 1),
(42, NULL, 'New Category Title Here...', 'temp', 0, NULL, 1, NULL, NULL, NULL, NULL, NULL, 'vi', '41fbhk', 'DRAFT', '2024-01-12 14:15:02', 1),
(43, NULL, 'New Category Title Here...', 'temp', 0, NULL, 1, '', NULL, '', '', NULL, 'vi', '11tglk', 'DRAFT', '2024-01-12 16:04:23', 1),
(44, '', 'New Category Title Here...', 'temp', 0, NULL, 1, '', '', '', '', NULL, 'vi', '50tadu', 'DRAFT', '2024-01-13 09:20:06', 1),
(45, '', 'xxxxxxxx', 'xxxxxxxx', 31, NULL, 2, '', '', '', '', '', 'en', '26enzh', 'DRAFT', '2024-01-16 09:18:55', 1),
(46, '', 'Hệ cửa nhôm', 'he-cua-nhom', 0, NULL, 1, '', '', '', '', '', 'vi', '59olxb', 'DRAFT', '2024-01-17 09:59:08', 1),
(47, NULL, 'jjjjjjjjjjjjjj', 'he-cua-nhom', 0, NULL, 1, '', NULL, '', '', NULL, 'en', '59olxb', 'DRAFT', '2024-01-16 09:23:30', 1);

-- --------------------------------------------------------

--
-- Table structure for table `pcounter_by_day`
--

DROP TABLE IF EXISTS `pcounter_by_day`;
CREATE TABLE IF NOT EXISTS `pcounter_by_day` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `day` date NOT NULL,
  `user` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=116 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `pcounter_by_day`
--

INSERT INTO `pcounter_by_day` (`id`, `day`, `user`) VALUES
(5, '2020-04-04', 10),
(6, '2020-04-03', 15),
(7, '2020-04-02', 10),
(8, '2020-04-05', 1),
(9, '2020-04-07', 0),
(10, '2020-04-08', 1),
(11, '2020-04-09', 1),
(12, '2020-04-11', 0),
(13, '2020-04-12', 1),
(14, '2020-04-13', 1),
(15, '2020-04-14', 1),
(16, '2020-04-15', 1),
(17, '2020-05-11', 0),
(18, '2020-05-18', 0),
(19, '2020-06-07', 0),
(20, '2020-06-08', 1),
(21, '2020-06-24', 0),
(22, '2020-06-25', 1),
(23, '2020-07-08', 0),
(24, '2020-11-02', 0),
(25, '2020-11-03', 1),
(26, '2020-11-04', 1),
(27, '2020-11-05', 1),
(28, '2020-11-08', 0),
(29, '2021-02-24', 0),
(30, '2021-02-26', 0),
(31, '2021-03-08', 0),
(32, '2021-03-09', 1),
(33, '2021-03-10', 1),
(34, '2021-03-11', 1),
(35, '2021-06-03', 0),
(36, '2021-06-04', 1),
(37, '2021-06-05', 1),
(38, '2021-06-06', 1),
(39, '2021-07-11', 0),
(40, '2021-11-16', 0),
(41, '2021-11-18', 0),
(42, '2021-11-21', 0),
(43, '2021-11-22', 1),
(44, '2021-11-23', 1),
(45, '2021-11-24', 1),
(46, '2021-11-25', 1),
(47, '2021-12-01', 0),
(48, '2022-01-19', 0),
(49, '2022-02-07', 0),
(50, '2022-02-10', 0),
(51, '2022-02-11', 1),
(52, '2022-02-12', 1),
(53, '2022-02-13', 1),
(54, '2022-09-12', 0),
(55, '2022-09-17', 0),
(56, '2022-09-18', 1),
(57, '2022-09-23', 0),
(58, '2022-09-24', 1),
(59, '2022-09-25', 1),
(60, '2022-09-26', 1),
(61, '2022-09-27', 2),
(62, '2022-09-28', 1),
(63, '2022-09-30', 0),
(64, '2022-10-01', 1),
(65, '2022-10-04', 0),
(66, '2022-10-05', 1),
(67, '2022-10-06', 1),
(68, '2022-10-07', 1),
(69, '2022-10-09', 0),
(70, '2022-10-27', 0),
(71, '2022-12-18', 0),
(72, '2023-02-15', 0),
(73, '2023-02-16', 1),
(74, '2023-02-18', 0),
(75, '2023-02-19', 1),
(76, '2023-02-20', 1),
(77, '2023-02-21', 1),
(78, '2023-02-22', 1),
(79, '2023-02-23', 1),
(80, '2023-02-25', 0),
(81, '2023-02-26', 1),
(82, '2023-02-27', 1),
(83, '2023-02-28', 1),
(84, '2023-03-01', 1),
(85, '2023-03-13', 0),
(86, '2023-03-15', 0),
(87, '2023-03-16', 1),
(88, '2023-03-17', 2),
(89, '2023-04-06', 0),
(90, '2023-04-08', 0),
(91, '2023-05-02', 0),
(92, '2023-05-04', 0),
(93, '2023-06-13', 0),
(94, '2023-06-18', 0),
(95, '2023-07-17', 0),
(96, '2023-07-19', 0),
(97, '2023-07-21', 0),
(98, '2023-07-31', 0),
(99, '2023-08-02', 0),
(100, '2023-08-06', 0),
(101, '2023-08-09', 0),
(102, '2023-08-13', 0),
(103, '2023-08-17', 0),
(104, '2023-08-23', 0),
(105, '2023-08-26', 0),
(106, '2023-08-27', 1),
(107, '2023-09-05', 0),
(108, '2023-11-20', 0),
(109, '2024-01-07', 0),
(110, '2024-01-08', 1),
(111, '2024-01-09', 1),
(112, '2024-01-11', 0),
(113, '2024-01-12', 1),
(114, '2024-01-14', 0),
(115, '2024-01-16', 0);

-- --------------------------------------------------------

--
-- Table structure for table `pcounter_save`
--

DROP TABLE IF EXISTS `pcounter_save`;
CREATE TABLE IF NOT EXISTS `pcounter_save` (
  `save_name` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `save_value` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`save_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `pcounter_save`
--

INSERT INTO `pcounter_save` (`save_name`, `save_value`) VALUES
('counter', 64),
('day_time', 2460327),
('max_count', 126),
('max_time', 1585890000),
('yesterday', 0);

-- --------------------------------------------------------

--
-- Table structure for table `pcounter_users`
--

DROP TABLE IF EXISTS `pcounter_users`;
CREATE TABLE IF NOT EXISTS `pcounter_users` (
  `user_ip` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `user_time` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`user_ip`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `pcounter_users`
--

INSERT INTO `pcounter_users` (`user_ip`, `user_time`) VALUES
('837ec5754f503cfaaee0929fd48974e7', 1705460336);

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

DROP TABLE IF EXISTS `posts`;
CREATE TABLE IF NOT EXISTS `posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cover` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `categories` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(300) COLLATE utf8_unicode_ci DEFAULT NULL,
  `slug` text COLLATE utf8_unicode_ci,
  `summary` text COLLATE utf8_unicode_ci,
  `content` text COLLATE utf8_unicode_ci,
  `date_created` datetime DEFAULT NULL,
  `date_updated` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  `seo_title` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_description` text COLLATE utf8_unicode_ci,
  `seo_image` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `post_status` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tags` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lang` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `post_type` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1937 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `code`, `cover`, `categories`, `title`, `slug`, `summary`, `content`, `date_created`, `date_updated`, `user_created`, `seo_title`, `seo_description`, `seo_image`, `post_status`, `tags`, `lang`, `post_type`) VALUES
(1897, '20230301-210941-UMlu', '', NULL, 'Global Presence', 'global-presence', NULL, '<div class=\"row g-5\">\r\n<div class=\"col-lg-4 wow slideInUp\" style=\"visibility: visible; animation-delay: 0.1s; animation-name: slideInUp;\" data-wow-delay=\"0.1s\">\r\n<div class=\"section-title bg-light rounded h-100 p-5\">\r\n<h5 class=\"position-relative d-inline-block text-primary text-uppercase\">Văn ph&ograve;ng v&agrave; Chi nh&aacute;nh</h5>\r\n<h1 class=\"display-6 mb-4\">Một viễn cảnh to&agrave;n cầu</h1>\r\n<p class=\"mb-4\">C&oacute; trụ sở ch&iacute;nh tại Singapore, ch&uacute;ng t&ocirc;i vận h&agrave;nh hai nh&agrave; m&aacute;y lọc dầu v&agrave; ch&iacute;n kho thu gom tr&ecirc;n khắp ch&acirc;u &Aacute;. Việc mở rộng v&agrave; t&iacute;ch hợp theo chiều dọc v&agrave; chiều ngang của ch&uacute;ng t&ocirc;i v&agrave;o c&aacute;c thị trường năng lượng sinh học đ&atilde; cho ph&eacute;p ch&uacute;ng t&ocirc;i kiểm so&aacute;t tốt hơn to&agrave;n bộ chuỗi cung ứng, từ đ&oacute; cung cấp c&aacute;c giải ph&aacute;p mong muốn hơn cho kh&aacute;ch h&agrave;ng của ch&uacute;ng t&ocirc;i.</p>\r\n<!-- <a href=\"appointment.html\" class=\"btn btn-primary py-3 px-5\">Appointment</a>--></div>\r\n</div>\r\n<div class=\"col-lg-4 wow slideInUp\" style=\"visibility: visible; animation-delay: 0.3s; animation-name: slideInUp;\" data-wow-delay=\"0.3s\">\r\n<div class=\"team-item\">\r\n<div class=\"position-relative rounded-top\" style=\"z-index: 1;\"><img class=\"img-fluid rounded-top w-100\" src=\"/images/posts/_branches/sing.jpg\" alt=\"\" />\r\n<div class=\"position-absolute top-100 start-50 translate-middle bg-light rounded p-2 d-flex\">&nbsp;</div>\r\n</div>\r\n<div class=\"team-text position-relative bg-light text-center rounded-bottom p-4 pt-5\">\r\n<h4 class=\"mb-2\">Singapore</h4>\r\n<p class=\"text-primary mb-0\">Singapore branch</p>\r\n<p class=\"text-primary mb-0\">Address: 8 Eu Tong Sen Street, Office 1, #21-98/99, The Central, Singapore 059818<br />120 Tuas South Avenue 2 West Point Bizhub Singapore 637165</p>\r\n<p class=\"text-primary mb-0\">Email: enail@gmail.com</p>\r\n<p class=\"text-primary mb-0\">Website: https://sin.com</p>\r\n<p class=\"text-primary mb-0\">other</p>\r\n</div>\r\n</div>\r\n</div>\r\n<div class=\"col-lg-4 wow slideInUp\" style=\"visibility: visible; animation-delay: 0.3s; animation-name: slideInUp;\" data-wow-delay=\"0.3s\">\r\n<div class=\"team-item\">\r\n<div class=\"position-relative rounded-top\" style=\"z-index: 1;\"><img class=\"img-fluid rounded-top w-100\" src=\"/images/posts/_branches/vn.jpg\" alt=\"\" />\r\n<div class=\"position-absolute top-100 start-50 translate-middle bg-light rounded p-2 d-flex\">&nbsp;</div>\r\n</div>\r\n<div class=\"team-text position-relative bg-light text-center rounded-bottom p-4 pt-5\">\r\n<h4 class=\"mb-2\">VietNam</h4>\r\n<p class=\"text-primary mb-0\">Apeiron Bioenergy (Viet Nam) Company Limited</p>\r\n<p class=\"text-primary mb-0\">Address: Kho B&igrave;nh Dương: 18/14 Hai B&agrave; Trưng Nối D&agrave;i, Khu Phố T&acirc;y B, Phường Đ&ocirc;ng H&ograve;a, TP. Dĩ An, tỉnh B&igrave;nh Dương <br />Kho H&agrave; Nội: X&oacute;m 5, Th&ocirc;n Văn Hội, X&atilde; Văn B&igrave;nh, Huyện Thường T&iacute;n, TP. H&agrave; Nội</p>\r\n</div>\r\n</div>\r\n</div>\r\n<!--  <div class=\"col-lg-4 wow slideInUp\" data-wow-delay=\"0.3s\">\r\n                    <div class=\"team-item\">\r\n                        <div class=\"position-relative rounded-top\" style=\"z-index: 1;\">\r\n                            <img class=\"img-fluid rounded-top w-100\" src=\"img/team-1.jpg\" alt=\"\">\r\n                            <div class=\"position-absolute top-100 start-50 translate-middle bg-light rounded p-2 d-flex\">\r\n                                <a class=\"btn btn-primary btn-square m-1\" href=\"#\"><i class=\"fab fa-twitter fw-normal\"></i></a>\r\n                                <a class=\"btn btn-primary btn-square m-1\" href=\"#\"><i class=\"fab fa-facebook-f fw-normal\"></i></a>\r\n                                <a class=\"btn btn-primary btn-square m-1\" href=\"#\"><i class=\"fab fa-linkedin-in fw-normal\"></i></a>\r\n                                <a class=\"btn btn-primary btn-square m-1\" href=\"#\"><i class=\"fab fa-instagram fw-normal\"></i></a>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"team-text position-relative bg-light text-center rounded-bottom p-4 pt-5\">\r\n                            <h4 class=\"mb-2\">Dr. John Doe</h4>\r\n                            <p class=\"text-primary mb-0\">Implant Surgeon</p>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n                <div class=\"col-lg-4 wow slideInUp\" data-wow-delay=\"0.6s\">\r\n                    <div class=\"team-item\">\r\n                        <div class=\"position-relative rounded-top\" style=\"z-index: 1;\">\r\n                            <img class=\"img-fluid rounded-top w-100\" src=\"img/team-2.jpg\" alt=\"\">\r\n                            <div class=\"position-absolute top-100 start-50 translate-middle bg-light rounded p-2 d-flex\">\r\n                                <a class=\"btn btn-primary btn-square m-1\" href=\"#\"><i class=\"fab fa-twitter fw-normal\"></i></a>\r\n                                <a class=\"btn btn-primary btn-square m-1\" href=\"#\"><i class=\"fab fa-facebook-f fw-normal\"></i></a>\r\n                                <a class=\"btn btn-primary btn-square m-1\" href=\"#\"><i class=\"fab fa-linkedin-in fw-normal\"></i></a>\r\n                                <a class=\"btn btn-primary btn-square m-1\" href=\"#\"><i class=\"fab fa-instagram fw-normal\"></i></a>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"team-text position-relative bg-light text-center rounded-bottom p-4 pt-5\">\r\n                            <h4 class=\"mb-2\">Dr. John Doe</h4>\r\n                            <p class=\"text-primary mb-0\">Implant Surgeon</p>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n                <div class=\"col-lg-4 wow slideInUp\" data-wow-delay=\"0.1s\">\r\n                    <div class=\"team-item\">\r\n                        <div class=\"position-relative rounded-top\" style=\"z-index: 1;\">\r\n                            <img class=\"img-fluid rounded-top w-100\" src=\"img/team-3.jpg\" alt=\"\">\r\n                            <div class=\"position-absolute top-100 start-50 translate-middle bg-light rounded p-2 d-flex\">\r\n                                <a class=\"btn btn-primary btn-square m-1\" href=\"#\"><i class=\"fab fa-twitter fw-normal\"></i></a>\r\n                                <a class=\"btn btn-primary btn-square m-1\" href=\"#\"><i class=\"fab fa-facebook-f fw-normal\"></i></a>\r\n                                <a class=\"btn btn-primary btn-square m-1\" href=\"#\"><i class=\"fab fa-linkedin-in fw-normal\"></i></a>\r\n                                <a class=\"btn btn-primary btn-square m-1\" href=\"#\"><i class=\"fab fa-instagram fw-normal\"></i></a>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"team-text position-relative bg-light text-center rounded-bottom p-4 pt-5\">\r\n                            <h4 class=\"mb-2\">Dr. John Doe</h4>\r\n                            <p class=\"text-primary mb-0\">Implant Surgeon</p>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n                <div class=\"col-lg-4 wow slideInUp\" data-wow-delay=\"0.3s\">\r\n                    <div class=\"team-item\">\r\n                        <div class=\"position-relative rounded-top\" style=\"z-index: 1;\">\r\n                            <img class=\"img-fluid rounded-top w-100\" src=\"img/team-4.jpg\" alt=\"\">\r\n                            <div class=\"position-absolute top-100 start-50 translate-middle bg-light rounded p-2 d-flex\">\r\n                                <a class=\"btn btn-primary btn-square m-1\" href=\"#\"><i class=\"fab fa-twitter fw-normal\"></i></a>\r\n                                <a class=\"btn btn-primary btn-square m-1\" href=\"#\"><i class=\"fab fa-facebook-f fw-normal\"></i></a>\r\n                                <a class=\"btn btn-primary btn-square m-1\" href=\"#\"><i class=\"fab fa-linkedin-in fw-normal\"></i></a>\r\n                                <a class=\"btn btn-primary btn-square m-1\" href=\"#\"><i class=\"fab fa-instagram fw-normal\"></i></a>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"team-text position-relative bg-light text-center rounded-bottom p-4 pt-5\">\r\n                            <h4 class=\"mb-2\">Dr. John Doe</h4>\r\n                            <p class=\"text-primary mb-0\">Implant Surgeon</p>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n                <div class=\"col-lg-4 wow slideInUp\" data-wow-delay=\"0.6s\">\r\n                    <div class=\"team-item\">\r\n                        <div class=\"position-relative rounded-top\" style=\"z-index: 1;\">\r\n                            <img class=\"img-fluid rounded-top w-100\" src=\"img/team-5.jpg\" alt=\"\">\r\n                            <div class=\"position-absolute top-100 start-50 translate-middle bg-light rounded p-2 d-flex\">\r\n                                <a class=\"btn btn-primary btn-square m-1\" href=\"#\"><i class=\"fab fa-twitter fw-normal\"></i></a>\r\n                                <a class=\"btn btn-primary btn-square m-1\" href=\"#\"><i class=\"fab fa-facebook-f fw-normal\"></i></a>\r\n                                <a class=\"btn btn-primary btn-square m-1\" href=\"#\"><i class=\"fab fa-linkedin-in fw-normal\"></i></a>\r\n                                <a class=\"btn btn-primary btn-square m-1\" href=\"#\"><i class=\"fab fa-instagram fw-normal\"></i></a>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"team-text position-relative bg-light text-center rounded-bottom p-4 pt-5\">\r\n                            <h4 class=\"mb-2\">Dr. John Doe</h4>\r\n                            <p class=\"text-primary mb-0\">Implant Surgeon</p>\r\n                        </div>\r\n                    </div>\r\n                </div> --></div>', '2023-03-01 21:10:45', NULL, 1, '', '', NULL, 'PUBLISH', '', 'vi', NULL),
(1898, '20230301-211052-3hPV', '', NULL, 'Global Presence', 'global-presence-2', NULL, '<div class=\"row g-5\">\r\n<div class=\"col-lg-4 wow slideInUp\" style=\"visibility: visible; animation-delay: 0.1s; animation-name: slideInUp;\" data-wow-delay=\"0.1s\">\r\n<div class=\"section-title bg-light rounded h-100 p-5\">\r\n<h5 class=\"position-relative d-inline-block text-primary text-uppercase\">Offices and Branches</h5>\r\n<h1 class=\"display-6 mb-4\">A Global Perspective</h1>\r\n<p class=\"mb-4\">Headquartered in Singapore, we operate two refineries and nine collection warehouses across Asia. Our vertical and horizontal expansion and integration into bioenergy markets has enabled us to gain better control over the entire supply chain, thereby providing more desirable solutions for our clients.</p>\r\n<!-- <a href=\"appointment.html\" class=\"btn btn-primary py-3 px-5\">Appointment</a>--></div>\r\n</div>\r\n<div class=\"col-lg-4 wow slideInUp\" style=\"visibility: visible; animation-delay: 0.3s; animation-name: slideInUp;\" data-wow-delay=\"0.3s\">\r\n<div class=\"team-item\">\r\n<div class=\"position-relative rounded-top\" style=\"z-index: 1;\"><img class=\"img-fluid rounded-top w-100\" src=\"/images/posts/_branches/sing.jpg\" alt=\"\" />\r\n<div class=\"position-absolute top-100 start-50 translate-middle bg-light rounded p-2 d-flex\">&nbsp;</div>\r\n</div>\r\n<div class=\"team-text position-relative bg-light text-center rounded-bottom p-4 pt-5\">\r\n<h4 class=\"mb-2\">Singapore</h4>\r\n<p class=\"text-primary mb-0\">Singapore branch</p>\r\n<p class=\"text-primary mb-0\">Address: 8 Eu Tong Sen Street, Office 1, #21-98/99, The Central, Singapore 059818<br />120 Tuas South Avenue 2 West Point Bizhub Singapore 637165</p>\r\n<p class=\"text-primary mb-0\">Email: enail@gmail.com</p>\r\n<p class=\"text-primary mb-0\">Website: https://sin.com</p>\r\n<p class=\"text-primary mb-0\">other</p>\r\n</div>\r\n</div>\r\n</div>\r\n<div class=\"col-lg-4 wow slideInUp\" style=\"visibility: visible; animation-delay: 0.3s; animation-name: slideInUp;\" data-wow-delay=\"0.3s\">\r\n<div class=\"team-item\">\r\n<div class=\"position-relative rounded-top\" style=\"z-index: 1;\"><img class=\"img-fluid rounded-top w-100\" src=\"/images/posts/_branches/vn.jpg\" alt=\"\" />\r\n<div class=\"position-absolute top-100 start-50 translate-middle bg-light rounded p-2 d-flex\">&nbsp;</div>\r\n</div>\r\n<div class=\"team-text position-relative bg-light text-center rounded-bottom p-4 pt-5\">\r\n<h4 class=\"mb-2\">VietNam</h4>\r\n<p class=\"text-primary mb-0\">Apeiron Bioenergy (Viet Nam) Company Limited</p>\r\n<p class=\"text-primary mb-0\">Address: Kho B&igrave;nh Dương: 18/14 Hai B&agrave; Trưng Nối D&agrave;i, Khu Phố T&acirc;y B, Phường Đ&ocirc;ng H&ograve;a, TP. Dĩ An, tỉnh B&igrave;nh Dương <br />Kho H&agrave; Nội: X&oacute;m 5, Th&ocirc;n Văn Hội, X&atilde; Văn B&igrave;nh, Huyện Thường T&iacute;n, TP. H&agrave; Nội</p>\r\n</div>\r\n</div>\r\n</div>\r\n<!--  <div class=\"col-lg-4 wow slideInUp\" data-wow-delay=\"0.3s\">\r\n                    <div class=\"team-item\">\r\n                        <div class=\"position-relative rounded-top\" style=\"z-index: 1;\">\r\n                            <img class=\"img-fluid rounded-top w-100\" src=\"img/team-1.jpg\" alt=\"\">\r\n                            <div class=\"position-absolute top-100 start-50 translate-middle bg-light rounded p-2 d-flex\">\r\n                                <a class=\"btn btn-primary btn-square m-1\" href=\"#\"><i class=\"fab fa-twitter fw-normal\"></i></a>\r\n                                <a class=\"btn btn-primary btn-square m-1\" href=\"#\"><i class=\"fab fa-facebook-f fw-normal\"></i></a>\r\n                                <a class=\"btn btn-primary btn-square m-1\" href=\"#\"><i class=\"fab fa-linkedin-in fw-normal\"></i></a>\r\n                                <a class=\"btn btn-primary btn-square m-1\" href=\"#\"><i class=\"fab fa-instagram fw-normal\"></i></a>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"team-text position-relative bg-light text-center rounded-bottom p-4 pt-5\">\r\n                            <h4 class=\"mb-2\">Dr. John Doe</h4>\r\n                            <p class=\"text-primary mb-0\">Implant Surgeon</p>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n                <div class=\"col-lg-4 wow slideInUp\" data-wow-delay=\"0.6s\">\r\n                    <div class=\"team-item\">\r\n                        <div class=\"position-relative rounded-top\" style=\"z-index: 1;\">\r\n                            <img class=\"img-fluid rounded-top w-100\" src=\"img/team-2.jpg\" alt=\"\">\r\n                            <div class=\"position-absolute top-100 start-50 translate-middle bg-light rounded p-2 d-flex\">\r\n                                <a class=\"btn btn-primary btn-square m-1\" href=\"#\"><i class=\"fab fa-twitter fw-normal\"></i></a>\r\n                                <a class=\"btn btn-primary btn-square m-1\" href=\"#\"><i class=\"fab fa-facebook-f fw-normal\"></i></a>\r\n                                <a class=\"btn btn-primary btn-square m-1\" href=\"#\"><i class=\"fab fa-linkedin-in fw-normal\"></i></a>\r\n                                <a class=\"btn btn-primary btn-square m-1\" href=\"#\"><i class=\"fab fa-instagram fw-normal\"></i></a>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"team-text position-relative bg-light text-center rounded-bottom p-4 pt-5\">\r\n                            <h4 class=\"mb-2\">Dr. John Doe</h4>\r\n                            <p class=\"text-primary mb-0\">Implant Surgeon</p>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n                <div class=\"col-lg-4 wow slideInUp\" data-wow-delay=\"0.1s\">\r\n                    <div class=\"team-item\">\r\n                        <div class=\"position-relative rounded-top\" style=\"z-index: 1;\">\r\n                            <img class=\"img-fluid rounded-top w-100\" src=\"img/team-3.jpg\" alt=\"\">\r\n                            <div class=\"position-absolute top-100 start-50 translate-middle bg-light rounded p-2 d-flex\">\r\n                                <a class=\"btn btn-primary btn-square m-1\" href=\"#\"><i class=\"fab fa-twitter fw-normal\"></i></a>\r\n                                <a class=\"btn btn-primary btn-square m-1\" href=\"#\"><i class=\"fab fa-facebook-f fw-normal\"></i></a>\r\n                                <a class=\"btn btn-primary btn-square m-1\" href=\"#\"><i class=\"fab fa-linkedin-in fw-normal\"></i></a>\r\n                                <a class=\"btn btn-primary btn-square m-1\" href=\"#\"><i class=\"fab fa-instagram fw-normal\"></i></a>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"team-text position-relative bg-light text-center rounded-bottom p-4 pt-5\">\r\n                            <h4 class=\"mb-2\">Dr. John Doe</h4>\r\n                            <p class=\"text-primary mb-0\">Implant Surgeon</p>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n                <div class=\"col-lg-4 wow slideInUp\" data-wow-delay=\"0.3s\">\r\n                    <div class=\"team-item\">\r\n                        <div class=\"position-relative rounded-top\" style=\"z-index: 1;\">\r\n                            <img class=\"img-fluid rounded-top w-100\" src=\"img/team-4.jpg\" alt=\"\">\r\n                            <div class=\"position-absolute top-100 start-50 translate-middle bg-light rounded p-2 d-flex\">\r\n                                <a class=\"btn btn-primary btn-square m-1\" href=\"#\"><i class=\"fab fa-twitter fw-normal\"></i></a>\r\n                                <a class=\"btn btn-primary btn-square m-1\" href=\"#\"><i class=\"fab fa-facebook-f fw-normal\"></i></a>\r\n                                <a class=\"btn btn-primary btn-square m-1\" href=\"#\"><i class=\"fab fa-linkedin-in fw-normal\"></i></a>\r\n                                <a class=\"btn btn-primary btn-square m-1\" href=\"#\"><i class=\"fab fa-instagram fw-normal\"></i></a>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"team-text position-relative bg-light text-center rounded-bottom p-4 pt-5\">\r\n                            <h4 class=\"mb-2\">Dr. John Doe</h4>\r\n                            <p class=\"text-primary mb-0\">Implant Surgeon</p>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n                <div class=\"col-lg-4 wow slideInUp\" data-wow-delay=\"0.6s\">\r\n                    <div class=\"team-item\">\r\n                        <div class=\"position-relative rounded-top\" style=\"z-index: 1;\">\r\n                            <img class=\"img-fluid rounded-top w-100\" src=\"img/team-5.jpg\" alt=\"\">\r\n                            <div class=\"position-absolute top-100 start-50 translate-middle bg-light rounded p-2 d-flex\">\r\n                                <a class=\"btn btn-primary btn-square m-1\" href=\"#\"><i class=\"fab fa-twitter fw-normal\"></i></a>\r\n                                <a class=\"btn btn-primary btn-square m-1\" href=\"#\"><i class=\"fab fa-facebook-f fw-normal\"></i></a>\r\n                                <a class=\"btn btn-primary btn-square m-1\" href=\"#\"><i class=\"fab fa-linkedin-in fw-normal\"></i></a>\r\n                                <a class=\"btn btn-primary btn-square m-1\" href=\"#\"><i class=\"fab fa-instagram fw-normal\"></i></a>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"team-text position-relative bg-light text-center rounded-bottom p-4 pt-5\">\r\n                            <h4 class=\"mb-2\">Dr. John Doe</h4>\r\n                            <p class=\"text-primary mb-0\">Implant Surgeon</p>\r\n                        </div>\r\n                    </div>\r\n                </div> --></div>', '2023-03-01 21:11:20', NULL, 1, '', '', NULL, 'PUBLISH', '', 'en', NULL),
(1899, '20230302-095720-NO9t', '', NULL, 'Sustainability', 'sustainability-en', NULL, '<h1 class=\"envionmnet-ttle\" data-w-id=\"23139613-11a9-b459-83dd-3d86c5ccdc8e\">Sustainability at Our Core<img class=\"environment-icon\" src=\"https://assets.website-files.com/622ecbb1fc363c1753ddeb5f/6230696327bb278eec2df55b_noun-green-city-1085044.svg\" alt=\"\" /></h1>\r\n<div class=\"enironmnet-content\">\r\n<div class=\"environmnet-text\">We collect wastes with the mission of protecting the environment, creating awareness, and representing the interests of the bioenergy industry.</div>\r\n</div>\r\n<div class=\"enironmnet-content\"><br />\r\n<div class=\"environmnet-text\">We implement rigorous ecological and social sustainability criteria in our supply chain management process. This process is audited regularly and our products are certified with sustainability standards such as International Sustainability &amp; Carbon Certification (ISCC) .</div>\r\n</div>\r\n<div class=\"enironmnet-content\"><br />\r\n<div class=\"environmnet-text\">Our business directly reduces the social costs of clogged sewage and reduced efficiency of wastewater treatment systems as a result of illegal disposal of used cooking oil.<br /><br />Through collaborations with local households, restaurants, hotels, food manufacturers, we create awareness and encourage the proper disposal of waste. At the same time, we create job opportunities for local economies through recycling activities.</div>\r\n<div class=\"environmnet-text\">&nbsp;</div>\r\n<div class=\"environmnet-text\">\r\n<h1 class=\"impact-title\" data-w-id=\"68f7fa92-83b1-c141-b7c7-897ff11d9b75\">Our Impact in Numbers</h1>\r\n<p><img src=\"/images/posts/20230302-095720-NO9t/image1.jpg\" alt=\"\" width=\"100%\" height=\"\" /></p>\r\n<p><img src=\"/images/posts/20230302-095720-NO9t/image2.jpg\" alt=\"\" width=\"100%\" height=\"\" /></p>\r\n</div>\r\n</div>', '2023-03-02 10:01:26', '2023-03-02 10:02:15', 1, '', '', NULL, 'PUBLISH', '', 'en', NULL),
(1900, '20230302-100247-rDeb', '', NULL, 'Sustainability', 'sustainability', NULL, '<h1>T&iacute;nh bền vững cốt l&otilde;i của ch&uacute;ng t&ocirc;i</h1>\r\n<p>Ch&uacute;ng t&ocirc;i thu gom r&aacute;c thải với sứ mệnh bảo vệ m&ocirc;i trường, n&acirc;ng cao nhận thức v&agrave; đại diện cho lợi &iacute;ch của ng&agrave;nh năng lượng sinh học.</p>\r\n<p>Ch&uacute;ng t&ocirc;i thực hiện c&aacute;c ti&ecirc;u ch&iacute; bền vững về x&atilde; hội v&agrave; sinh th&aacute;i nghi&ecirc;m ngặt trong quy tr&igrave;nh quản l&yacute; chuỗi cung ứng của m&igrave;nh. Qu&aacute; tr&igrave;nh n&agrave;y được kiểm tra thường xuy&ecirc;n v&agrave; c&aacute;c sản phẩm của ch&uacute;ng t&ocirc;i được chứng nhận với c&aacute;c ti&ecirc;u chuẩn bền vững như Chứng nhận Carbon &amp; Bền vững Quốc tế (ISCC) dầu mỏ.</p>\r\n<p>Th&ocirc;ng qua sự hợp t&aacute;c với c&aacute;c hộ gia đ&igrave;nh, nh&agrave; h&agrave;ng, kh&aacute;ch sạn, nh&agrave; sản xuất thực phẩm địa phương, ch&uacute;ng t&ocirc;i n&acirc;ng cao nhận thức v&agrave; khuyến kh&iacute;ch việc xử l&yacute; r&aacute;c thải đ&uacute;ng c&aacute;ch.</p>\r\n<p>Đồng thời, ch&uacute;ng t&ocirc;i tạo cơ hội việc l&agrave;m cho c&aacute;c nền kinh tế địa phương th&ocirc;ng qua c&aacute;c hoạt động t&aacute;i chế.</p>\r\n<h1>T&aacute;c động của ch&uacute;ng t&ocirc;i về số lượng</h1>\r\n<p><img src=\"/images/posts/20230302-100247-rDeb/image1.jpg\" alt=\"\" width=\"100%\" /></p>\r\n<p><img src=\"/images/posts/20230302-100247-rDeb/image2.jpg\" alt=\"\" width=\"100%\" /></p>', '2023-03-02 10:05:42', '2023-03-02 10:05:49', 1, '', '', NULL, 'PUBLISH', '', 'vi', NULL),
(1901, '20230302-101637-p6rU', 'https://apeironbioenergy.vn/images/posts/default.jpg', 'tin-tuc', 'Thu mua dầu ăn đã qua sử dụng để xuất khẩu làm dầu Biodiesel', 'thu-mua-dau-an-da-qua-su-dung-de-xuat-khau-lam-dau-biodiesel', 'Hiện nay, quá trình chế biến thực phẩm tại các bếp ăn tập thể, khách sạn, nhà hàng, trường học, bệnh viện, các gia đình,… trên toàn quốc sản sinh ra lượng lớn dầu ăn đã qua sử dụng.', '<h2>Thu mua dầu ăn đ&atilde; qua sử dụng</h2>\r\n<p>Ch&uacute;ng t&ocirc;i chuy&ecirc;n thu gom dầu ăn đ&atilde; qua sử dụng tr&ecirc;n cả nước để xuất khẩu l&agrave;m dầu Biodiesel (B5, B10&hellip;) một nguồn nhi&ecirc;n liệu sinh học th&acirc;n thiện với m&ocirc;i trường. C&ocirc;ng ty đ&atilde; k&yacute; hợp đồng thu gom v&agrave; xuất khẩu h&agrave;ng trăm tấn dầu thải h&agrave;ng th&aacute;ng từ c&aacute;c hệ thống Nh&agrave; h&agrave;ng, tiệc cưới, suất ăn c&ocirc;ng nghiệp, si&ecirc;u thị, trường học&hellip; v&agrave; c&aacute;c hệ thống kh&aacute;c tr&ecirc;n phạm vi to&agrave;n quốc.</p>\r\n<p>Ở c&aacute;c địa phương thường mua dầu thải n&agrave;y với gi&aacute; cao, sau đ&oacute; d&ugrave;ng h&oacute;a chất t&aacute;i chế lại th&agrave;nh &ldquo;dầu đỏ&rdquo; b&aacute;n cho c&aacute;c cơ sở chui l&agrave;m dầu chi&ecirc;n h&agrave;nh phi, l&agrave;m b&aacute;nh kẹo, chi&ecirc;n quẩy, ng&ocirc; chi&ecirc;n, cơm rang, phở x&agrave;o, g&agrave; r&aacute;n,&hellip; hoặc d&ugrave;ng thủ đoạn d&aacute;n m&aacute;c c&aacute;c h&atilde;ng dầu ăn nổi tiếng để lừa b&aacute;n cho người ti&ecirc;u d&ugrave;ng, g&acirc;y ảnh hưởng nghi&ecirc;m trọng đến sức khỏe người d&acirc;n, một t&aacute;c nh&acirc;n g&acirc;y nhiều bệnh ung thư. Ch&uacute;ng lợi dụng c&aacute;c nh&agrave; h&agrave;ng, kh&aacute;ch sạn,&hellip; với c&aacute;c chi&ecirc;u b&agrave;i như &ldquo; mua dầu ăn thải để sản xuất thức ăn gia s&uacute;c&hellip; để lấy được dầu ăn thải về t&aacute;i chế.</p>\r\n<p><img src=\"/images/posts/20230302-101637-p6rU/2155d467c6451c1b4554.jpg\" alt=\"\" width=\"100%\" /></p>\r\n<h2>Chung tay bảo vệ m&ocirc;i trường</h2>\r\n<p>Dầu ăn đ&atilde; qua sử dụng c&oacute; lượng acid cao n&ecirc;n người, vật nu&ocirc;i đều kh&ocirc;ng ăn được. Nhiều cơ sở, nh&agrave; h&agrave;ng, kh&aacute;ch sạn, qu&aacute;n ăn&hellip; đổ dầu đ&atilde; qua sử dụng xuống cống r&atilde;nh&hellip; g&acirc;y &ocirc; nhiễm m&ocirc;i trường v&agrave; l&atilde;ng ph&iacute; nguồn nhi&ecirc;n liệu, thậm ch&iacute; tạo điều kiện cho c&aacute;c đối tượng xấu m&uacute;c lại dầu thải dưới cống r&atilde;nh về t&aacute;i chế lại lừa b&aacute;n ra thị trường như b&aacute;o ch&iacute; từng đưa tin.</p>\r\n<p>V&igrave; m&ocirc;i trường trong sạch, v&igrave; sức khỏe cộng đồng, C&ocirc;ng ty rất mong nhận được sự hợp t&aacute;c của qu&yacute; cơ quan, doanh nghiệp v&agrave; cộng đồng thu gom dầu đen xuất khẩu, g&oacute;p phần chống t&aacute;i chế v&agrave; tiết kiệm nguồn nhi&ecirc;n liệu.</p>\r\n<p>H&atilde;y chung tay v&igrave; sức khỏe v&agrave; bảo vệ m&ocirc;i trường cộng đồng!</p>\r\n<p>Vui l&ograve;ng li&ecirc;n hệ:</p>\r\n<p><strong>C&ocirc;ng ty Aperion Bioenergy Việt Nam:</strong></p>\r\n<ul>\r\n<li>Kho B&igrave;nh Dương: 18/14 Hai B&agrave; Trưng Nối D&agrave;i, Khu Phố T&acirc;y B, Phường Đ&ocirc;ng H&ograve;a, TP. Dĩ An, tỉnh B&igrave;nh Dương</li>\r\n<li>Kho H&agrave; Nội: X&oacute;m 5, Th&ocirc;n Văn Hội, X&atilde; Văn B&igrave;nh, Huyện Thường T&iacute;n, TP. H&agrave; Nội</li>\r\n</ul>', '2023-03-02 10:25:51', '2023-03-18 13:39:47', 1, '', '', NULL, 'PUBLISH', '', 'vi', NULL),
(1902, '20230302-103515-uvPk', 'https://apeironbioenergy.vn/images/posts/default.jpg', 'tin-tuc', 'Thu mua mỡ lợn (heo) làm nguyên liệu sản xuất dầu thân thiện môi trường', 'thu-mua-mo-lon-heo-lam-nguyen-lieu-san-xuat-dau-than-thien-moi-truong', 'Do nhu cầu sản xuất và xuất khẩu của công ty, chúng tôi cần thu mua lượng lớn các loại Mỡ heo (lợn), Macgarin, mỡ. ', '<h2><img src=\"/images/posts/20230302-101637-p6rU/2155d467c6451c1b4554.jpg\" alt=\"\" width=\"100%\" /></h2>\r\n<h2>Thu mua mỡ lợn (heo) số lượng lớn</h2>\r\n<p>Nếu c&ocirc;ng ty, c&aacute; nh&acirc;n hay doanh nghiệp n&agrave;o c&oacute; nhu cầu cung cấp với số lượng nhiều v&agrave; đều đặn th&igrave; vui l&ograve;ng li&ecirc;n hệ:</p>\r\n<p><strong>C&ocirc;ng ty Aperion Bioenergy Việt Nam</strong></p>\r\n<ul>\r\n<li>Kho B&igrave;nh Dương: 18/14 Hai B&agrave; Trưng Nối D&agrave;i, Khu Phố T&acirc;y B, Phường Đ&ocirc;ng H&ograve;a, TP. Dĩ An, tỉnh B&igrave;nh Dương</li>\r\n<li>Kho H&agrave; Nội: X&oacute;m 5, Th&ocirc;n Văn Hội, X&atilde; Văn B&igrave;nh, Huyện Thường T&iacute;n, TP. H&agrave; Nội</li>\r\n</ul>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>', '2023-03-02 10:37:52', '2023-03-18 13:39:39', 1, '', '', NULL, 'PUBLISH', '', 'vi', NULL),
(1903, '20230302-103901-kw5Q', '', 'tin-tuc', 'Buying used cooking oil for export to make Biodiesel oil', 'buying-used-cooking-oil-for-export-to-make-biodiesel-oil', 'Currently, the food processing process at collective kitchens, hotels, restaurants, schools, hospitals, families, etc. nationwide produces a large amount of used cooking oil.', '<h2>Buying used cooking oil</h2>\r\n<p>We specialize in collecting used cooking oil across the country to export to make Biodiesel (B5, B10&hellip;) an environmentally friendly source of biofuel. The company has signed contracts to collect and export hundreds of tons of waste oil monthly from restaurants, wedding parties, industrial catering, supermarkets, schools... and other systems nationwide.</p>\r\n<p>In localities, it is common to buy this waste oil at a high price, then recycle it into \"red oil\" using chemicals and sell it to underground establishments that make fried oil, confectionery, fried rice, fried corn, and fried rice. , fried pho, fried chicken, ... or using tricks to label famous cooking oil companies to trick them into selling them to consumers, seriously affecting people\'s health, a cause of many cancers.</p>\r\n<p>They take advantage of restaurants, hotels, ... with the guise of \"buying waste cooking oil to produce animal feed... to get the waste cooking oil for recycling.</p>\r\n<p><img src=\"/images/posts/20230302-101637-p6rU/2155d467c6451c1b4554.jpg\" alt=\"\" width=\"100%\" /></p>\r\n<h2>Join hands to protect the environment</h2>\r\n<p>Used cooking oil has a high acid content, so people and pets can\'t eat it. Many establishments, restaurants, hotels, eateries&hellip; dump used oil into the sewers&hellip; polluting the environment and wasting fuel, even creating conditions for bad actors to scoop up the waste oil below. sewers for recycling are tricked into selling to the market as reported by the press.</p>\r\n<p>For the sake of the clean environment, for public health, the Company is looking forward to receiving the cooperation of your agencies, businesses and the revenue community. collect black oil for export, contribute to anti-recycling and save fuel.</p>\r\n<p>Let\'s join hands for the health and environmental protection of the community!</p>\r\n<p>Please contact:</p>\r\n<p>Aperion Bioenergy Vietnam</p>\r\n<ul>\r\n<li>Kho B&igrave;nh Dương: 18/14 Hai B&agrave; Trưng Nối D&agrave;i, Khu Phố T&acirc;y B, Phường Đ&ocirc;ng H&ograve;a, TP. Dĩ An, tỉnh B&igrave;nh Dương</li>\r\n<li>Kho H&agrave; Nội: X&oacute;m 5, Th&ocirc;n Văn Hội, X&atilde; Văn B&igrave;nh, Huyện Thường T&iacute;n, TP. H&agrave; Nội</li>\r\n</ul>', '2023-03-02 10:41:31', NULL, 1, '', '', NULL, 'PUBLISH', '', 'en', NULL),
(1904, '20230302-104137-Xiw5', '', 'tin-tuc', 'Purchase of lard (pork) as a raw material for the production of eco-friendly oil', 'purchase-of-lard-pork-as-a-raw-material-for-the-production-of-eco-friendly-oil', 'Due to the production and export needs of the company, we need to buy a large amount of pork fat (pig), margarin, fat.', '<h2><img src=\"/images/posts/20230302-103515-uvPk/2155d467c6451c1b4554.jpg\" alt=\"\" width=\"100%\" /></h2>\r\n<h2>Bulk purchase of lard (pork)</h2>\r\n<p>If any company, individual or business needs to supply in large quantities and regularly, please contact:</p>\r\n<p><strong>Aperion Bioenergy Vietnam</strong></p>\r\n<ul>\r\n<li>Kho B&igrave;nh Dương: 18/14 Hai B&agrave; Trưng Nối D&agrave;i, Khu Phố T&acirc;y B, Phường Đ&ocirc;ng H&ograve;a, TP. Dĩ An, tỉnh B&igrave;nh Dương</li>\r\n<li>Kho H&agrave; Nội: X&oacute;m 5, Th&ocirc;n Văn Hội, X&atilde; Văn B&igrave;nh, Huyện Thường T&iacute;n, TP. H&agrave; Nội</li>\r\n</ul>', '2023-03-02 10:43:27', NULL, 1, '', '', NULL, 'PUBLISH', '', 'en', NULL),
(1905, '20230722-102116-Mlv5', 'https://apeironbioenergy.vn/images/posts/20230722-102116-Mlv5/xu%20ly%20dau%20an%20thua.png', 'tin-tuc', 'CÁCH XỬ LÝ DẦU ĂN THỪA ĐÃ QUA SỬ DỤNG ', 'cach-xu-ly-da-u-an-thu-a-da-qua-su-du-ng', 'Có thể bạn chưa biết dầu mỡ thừa là những chất khó phân hủy và có độ bám dính cao. Sau một thời gian lượng dầu mỡ thừa này bám đóng vào trong đường cống gây ra tình trạng ống thoát nước bị tắc và bốc mùi hôi thối. Để xử lý dầu ăn thừa các chị em nội trợ tuyệt đối không đổ trực tiếp xuống đường ống thoát nước mà nên để nguội rồi cho vào chai, lọ tìm cách tái chế hoặc đưa cho những nơi tái chế, thu mua dầu thừa để họ sản xuất chất đốt công nghiệp .', '<p><span style=\"font-size: 18pt;\"><strong>C&Aacute;CH XỬ L&Yacute; D&Acirc;̀U ĂN THỪA Đ&Atilde; QUA SỬ DỤNG</strong></span></p>\r\n<p><strong><img src=\"/images/posts/20230302-101637-p6rU/xu%20ly%20dau%20an%20thua.png\" alt=\"\" width=\"100%\" height=\"\" /></strong></p>\r\n<p>C&oacute; phải bạn vẫn c&oacute; th&oacute;i quen đổ trực tiếp lượng dầu mỡ thừa sau khi chi&ecirc;n thức ăn trực tiếp xuống ống cống tho&aacute;t nước của bồn rửa b&aacute;t ? Bạn nghĩ kh&ocirc;ng c&oacute; vấn đề g&igrave; v&igrave; nước sẽ cuốn sạch lượng dầu đ&oacute; theo đường nước thải?</p>\r\n<p>C&oacute; thể bạn chưa biết dầu mỡ thừa l&agrave; những chất kh&oacute; ph&acirc;n hủy v&agrave; c&oacute; độ b&aacute;m d&iacute;nh cao. Sau một thời gian lượng dầu mỡ thừa n&agrave;y b&aacute;m đ&oacute;ng v&agrave;o trong đường cống g&acirc;y ra t&igrave;nh trạng ống tho&aacute;t nước bị tắc v&agrave; bốc m&ugrave;i h&ocirc;i thối. Để xử l&yacute; dầu ăn thừa c&aacute;c chị em nội trợ tuyệt đối kh&ocirc;ng đổ trực tiếp xuống đường ống tho&aacute;t nước m&agrave; n&ecirc;n để nguội rồi cho v&agrave;o chai, lọ t&igrave;m c&aacute;ch t&aacute;i ch&ecirc;́ hoặc đưa cho những nơi t&aacute;i ch&ecirc;́, thu mua dầu thừa để họ sản xu&acirc;́t chất đốt c&ocirc;ng nghi&ecirc;̣p .</p>\r\n<p>Dưới đ&acirc;y l&agrave; những điều kh&ocirc;ng n&ecirc;n l&agrave;m với dầu ăn đ&atilde; qua sử dụng v&agrave; c&aacute;ch xử l&yacute; dầu ăn thừa để vừa tiết kiệm vừa an to&agrave;n.</p>\r\n<p><strong>Những điều cần tr&aacute;nh khi xử l&yacute; dầu ăn thừa:</strong></p>\r\n<p><strong>1 Kh&ocirc;ng đổ dầu</strong><strong> thừa</strong><strong> xuống cống</strong><strong>-bồn rửa</strong></p>\r\n<p>Dầu mỡ thừa l&agrave; một dạng chất lỏng nhưng kh&aacute;c hẳn so với nước. Ch&uacute;ng kh&ocirc;ng tan trong nước, khi để nguội v&agrave; gặp điều kiện th&iacute;ch hợp ch&uacute;ng sẽ rắn lại v&agrave; đ&ocirc;ng đặc tạo th&agrave;nh những mảng b&aacute;m d&iacute;nh chặt b&ecirc;n trong th&agrave;nh ống g&acirc;y tắc nghẽn.</p>\r\n<p>Việc đổ dầu ăn xuống cống r&atilde;nh, ống tho&aacute;t nước, bồn rửa b&aacute;t hoặc bồn cầu sẽ g&acirc;y tắc nghẽn hệ thống đường ống dẫn nước của gia đ&igrave;nh bạn v&agrave; g&oacute;p phần l&agrave;m tắc nghẽn diện rộng ở c&aacute;c đường ống nước trong th&agrave;nh phố, c&oacute; thể g&acirc;y thiệt hại nghi&ecirc;m trọng đến m&ocirc;i trường v&agrave; kinh tế.</p>\r\n<p>B&ecirc;n cạnh đ&oacute;, theo thời gian dầu mỡ sẽ theo đường ống dẫn v&agrave;o mạch nước ngầm, thẩm thấu v&agrave;o trong đất g&acirc;y &ocirc; nhiễm, ảnh hưởng đến chất lượng nước sinh hoạt. (Theo PGS.TS Trần Hồng C&ocirc;n (ĐH Khoa Học &ndash; Tự Nhi&ecirc;n).</p>\r\n<p><strong>2 Kh&ocirc;ng</strong> <strong>Đổ dầu ăn ra b&ecirc;n ngo&agrave;i</strong></p>\r\n<p>Nếu bạn đổ dầu tr&ecirc;n mặt đất, c&oacute; thể ch&uacute;ng sẽ đọng lại, chảy xuống hệ thống cống v&agrave; g&acirc;y tắc nghẽn ở đ&oacute;. Ngo&agrave;i ra, c&aacute;c loại dầu v&agrave; mỡ c&oacute; nguồn gốc động vật, thực vật c&oacute; thể g&acirc;y hại cho động vật khi ch&uacute;ng lỡ ăn phải (theo EPA - Cục Bảo vệ M&ocirc;i trường Mỹ).</p>\r\n<p>Một lượng lớn dầu ăn thấm v&agrave;o đất nơi c&oacute; c&acirc;y trồng sẽ g&acirc;y ra c&aacute;c vấn đề về luồng kh&ocirc;ng kh&iacute; v&agrave; độ ẩm, l&agrave;m hỏng ph&acirc;n b&oacute;n.</p>\r\n<p><span style=\"font-size: 14pt;\"><strong>C&aacute;ch xử l&yacute; dầu ăn thừa</strong></span></p>\r\n<p><strong><img src=\"/images/posts/20230302-101637-p6rU/Natural%20Minimal%20Two%20Tone%20Do%20Dont%20Facebook%20Post%20(1).png\" alt=\"\" width=\"100%\" height=\"\" /></strong></p>\r\n<p>C&aacute;ch xử l&yacute; dầu thừa rất đơn giản, nhưng h&atilde;y nhớ tuyệt đối tr&aacute;nh c&aacute;c trường hợp đ&atilde; n&oacute;i ở tr&ecirc;n. Bạn chỉ cần vứt dầu ăn v&agrave;o th&ugrave;ng r&aacute;c, tuy nhi&ecirc;n h&atilde;y l&agrave;m theo c&aacute;c bước dưới đ&acirc;y:</p>\r\n<p>Để dầu, mỡ nguội hẳn hoặc đ&ocirc;ng đặc lại.</p>\r\n<p>Sau khi dầu nguội, h&atilde;y cho ch&uacute;ng v&agrave;o vỏ chai đựng nước hoặc lọ thủy tinh để t&aacute;i chế l&agrave;m x&agrave; ph&ograve;ng hoặc đem đến những nơi thu mua dầu ăn thừa để họ chế tạo chất đốt.</p>\r\n<p>H&atilde;y chung tay bảo vệ m&ocirc;i trường xanh-sạch-đẹp</p>\r\n<p>-------------------------------------------------------</p>\r\n<p>Nếu bạn c&oacute; dầu ăn thừa &nbsp;đ&atilde; qua sử dụng h&atilde;y li&ecirc;n hệ với ch&uacute;ng t&ocirc;i</p>\r\n<p><strong>C&Ocirc;NG TY TNHH APEIRON BIOENERGY (VIET NAM) </strong></p>\r\n<p><strong>Địa chỉ : 18/14 Hai B&agrave; Trưng (Nối d&agrave;i) , KP T&acirc;y B, Phường Đ&ocirc;ng H&ograve;a, TP Dĩ An, Tỉnh B&igrave;nh Dương </strong></p>\r\n<p><strong>Hotline Miền Nam: 0977240268</strong></p>\r\n<p><strong>Hotline Miền Bắc: 0971128999</strong></p>\r\n<p>Apeiron Bioenergy (Viet Nam) chuy&ecirc;n thu mua dầu ăn đ&atilde; qua sử dụng để xuất khẩu l&agrave;m dầu Biodiesel , tuyệt đối kh&ocirc;ng t&aacute;i chế sử dụng lại cho người hoặc vật nu&ocirc;i.</p>\r\n<p>Ch&uacute;ng t&ocirc;i thu gom tận nơi ở một số khu vực tr&ecirc;n to&agrave;n quốc như: TP Hồ Ch&iacute; Minh, H&agrave; Nội, B&igrave;nh Dương, Đồng Nai, Nha Trang, Đ&agrave; Nẵng, Cần Thơ, Long An, BMT&hellip;</p>\r\n<p>&nbsp;</p>', '2023-07-22 10:26:52', '2023-08-03 16:00:19', 1, '', '', NULL, 'PUBLISH', '', 'vi', NULL),
(1906, '20230801-171903-uSOt', 'https://apeironbioenergy.vn/images/posts/20230801-171903-uSOt/2.png', 'tin-tuc', 'CÓ NÊN TÁI SỬ DỤNG LẠI DẦU ĂN ?', 'co-nen-tai-su-dung-lai-dau-an', 'Theo bác sĩ Hà Hải Nam (Phó trưởng khoa ngoại tiêu hóa 1, Bệnh Viện K Hà Nội ) cho biết:\r\n“Cứ mỗi lần tái sử dụng dầu ăn để chiên, xào, hàm lượng chất béo chuyển hóa sẽ tăng lên từ 2-6 lần, chất béo trung tính (loại không gây hại) bị phân hủy, oxy hóa các gốc acid béo tự do, giải phóng một chất gây ung thư có tên Acrolein. Dùng dầu chiên đi chiên lại nhiều lần cũng không còn giá trị dinh dưỡng như ban đầu”.\r\n', '<p><strong>C&Oacute; N&Ecirc;N T&Aacute;I SỬ DỤNG LẠI DẦU ĂN ?</strong></p>\r\n<p><img src=\"/images/posts/20230801-171903-uSOt/2.png\" alt=\"\" width=\"100%\" height=\"\" /></p>\r\n<p>Việc sử dụng dầu ăn hầu như l&agrave; mỗi ng&agrave;y của c&aacute;c gia đ&igrave;nh, d&ugrave; &iacute;t hay nhiều cho chi&ecirc;n ,x&agrave;o, nấu.</p>\r\n<p>Đối với việc sử dụng dầu ăn chi&ecirc;n đồ ăn phải chi&ecirc;n ngập dầu th&igrave; mới c&oacute; đạt được độ gi&ograve;n của thức ăn như c&aacute; chi&ecirc;n, g&agrave; chi&ecirc;n&hellip; chi&ecirc;n ngập dầu đồng nghĩa với lượng dầu dư sau đ&oacute; rất nhiều, bỏ đi th&igrave; uổng ph&iacute;, mới chi&ecirc;n một lần c&ograve;n rất mới, n&ecirc;n việc lựa chọn giữ lại t&aacute;i sử dụng được nhiều chị em l&agrave;m nhằm tiết kiệm hơn đ&uacute;ng kh&ocirc;ng ?</p>\r\n<p>C&oacute; rất nhiều c&aacute;ch để t&aacute;i sử dụng dầu ăn như d&ugrave;ng m&agrave;ng lọc ,giấy lọc dầu để lọc c&aacute;c cặn thức ăn v&agrave; thu về lớp dầu sạch như ta mong muốn.</p>\r\n<p><strong>Nhưng liệu c&oacute; những nguy hiểm g&igrave; khi sử dụng lại dầu ăn sau một lần chi&ecirc;n ?</strong></p>\r\n<p>Nhiệt độ cao sẽ ph&aacute; vỡ c&aacute;c th&agrave;nh phần dinh dưỡng trong dầu mỡ. Nhiệt độ s&ocirc;i của dầu ch&iacute;nh l&agrave; giới hạn an to&agrave;n cho sức khỏe , như dầu oliu 190 độ C, dầu lạc 230 độ C, dầu vừng 177 độ C, dầu đậu n&agrave;nh 240 độ C, mỡ lợn 130 đến 200 độ C. Trong khi, mức nhiệt được khuyến c&aacute;o l&agrave; dưới 180 độ C. Nếu tr&ecirc;n mức nhiệt n&agrave;y, thức ăn sẽ sản sinh chất Acrylamide, một chất g&acirc;y ung thư đ&atilde; được Bộ Y tế khuyến c&aacute;o. Lưu &yacute;, kể cả chi&ecirc;n dầu với nhiệt độ vừa phải nhưng qu&aacute; l&acirc;u cũng sinh ra độc tố, nhất l&agrave; thức ăn chứa tinh bột, đường như b&aacute;nh bao, b&aacute;nh r&aacute;n, đồ tẩm bột.</p>\r\n<p>Theo b&aacute;c sĩ H&agrave; Hải Nam (Ph&oacute; trưởng khoa ngoại ti&ecirc;u h&oacute;a 1, Bệnh Viện K H&agrave; Nội ) cho biết:</p>\r\n<p>&ldquo;Cứ mỗi lần t&aacute;i sử dụng dầu ăn để chi&ecirc;n, x&agrave;o, h&agrave;m lượng chất b&eacute;o chuyển h&oacute;a sẽ tăng l&ecirc;n từ 2-6 lần, chất b&eacute;o trung t&iacute;nh (loại kh&ocirc;ng g&acirc;y hại) bị ph&acirc;n hủy, oxy h&oacute;a c&aacute;c gốc acid b&eacute;o tự do, giải ph&oacute;ng một chất g&acirc;y ung thư c&oacute; t&ecirc;n Acrolein. D&ugrave;ng dầu chi&ecirc;n đi chi&ecirc;n lại nhiều lần cũng kh&ocirc;ng c&ograve;n gi&aacute; trị dinh dưỡng như ban đầu&rdquo;.</p>\r\n<p>Vậy tốt nhất để bảo vệ sức khỏe cho cả gia đ&igrave;nh, ch&uacute;ng ta n&ecirc;n hạn chế t&aacute;i sử dụng lại dầu ăn đ&atilde; qua sử dụng.</p>\r\n<p>V&agrave; đặc biệt, kh&ocirc;ng n&ecirc;n đổ dầu thừa xuống bồn rửa b&aacute;t hay th&ugrave;ng r&aacute;c, đổ v&agrave;o chai lọ dư v&agrave; li&ecirc;n hệ với những đơn vị thu gom dầu ăn thừa để sử dụng sản xuất dầu biodiesel gi&uacute;p bảo vệ m&ocirc;i trường.</p>\r\n<p>&nbsp;</p>\r\n<p><strong>C&Ocirc;NG TY TNHH APEIRON BIOENERGY (VIET NAM)</strong></p>\r\n<p><strong>Địa chỉ : 18/14 Hai B&agrave; Trưng (Nối d&agrave;i) , KP T&acirc;y B, Phường Đ&ocirc;ng H&ograve;a, TP Dĩ An, Tỉnh B&igrave;nh Dương</strong></p>\r\n<p><strong>Hotline Miền Nam: 0977240268</strong></p>\r\n<p><strong>Hotline Miền Bắc: 0971128999</strong></p>\r\n<p>Apeiron Bioenergy (Viet Nam) chuy&ecirc;n thu mua dầu ăn đ&atilde; qua sử dụng để xuất khẩu l&agrave;m dầu Biodiesel , tuyệt đối kh&ocirc;ng t&aacute;i chế sử dụng lại cho người hoặc vật nu&ocirc;i.</p>\r\n<p>Ch&uacute;ng t&ocirc;i thu gom tận nơi ở một số khu vực tr&ecirc;n to&agrave;n quốc như: TP Hồ Ch&iacute; Minh, H&agrave; Nội, B&igrave;nh Dương, Đồng Nai, Nha Trang, Đ&agrave; Nẵng, Cần Thơ, Long An, BMT&hellip;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>', '2023-08-01 17:21:44', '2023-08-03 15:51:45', 1, '', '', NULL, 'PUBLISH', '', 'vi', NULL),
(1907, '20230807-134007-ltZ0', 'https://apeironbioenergy.vn/images/posts/20230807-134007-ltZ0/quy%20trinh%20thu%20gom.jpg', 'tin-tuc', 'QUY TRÌNH THU GOM DẦU ĂN ĐÃ QUA SỬ DỤNG CTY APEIRON BIOENERGY (VIET NAM)', 'quy-trinh-thu-gom-dau-an-da-qua-su-dung-cty-apeiron-bioenergy-viet-nam', '', '<p><img src=\"/images/posts/quy%20trinh%20thu%20gom.jpg\" alt=\"\" width=\"100%\" /></p>', '2023-08-07 13:44:11', '2023-08-24 17:01:39', 1, '', '', NULL, 'PUBLISH', '', 'vi', NULL);
INSERT INTO `posts` (`id`, `code`, `cover`, `categories`, `title`, `slug`, `summary`, `content`, `date_created`, `date_updated`, `user_created`, `seo_title`, `seo_description`, `seo_image`, `post_status`, `tags`, `lang`, `post_type`) VALUES
(1908, '20230810-220713-JD3U', 'https://apeironbioenergy.vn/images/posts/20230810-220713-JD3U/6252c027b0109d28b12e47db_Apeiron%20Card.jpg', NULL, 'Công Ty Apeiron Bioenergy  trụ sở tại Singapore huy động 37 triệu đô để mở rộng mạng lưới nhiên liệu sinh học', 'cong-ty-apeiron-bioenergy-tru-so-tai-singapore-huy-dong-37-trieu-do-de-mo-rong-mang-luoi-nhien-lieu-sinh-hoc', 'Startup nhiên liệu sinh học trụ sở tại Singapore Apeiron Bioenergy vừa huy động được 50 triệu đô la Singapore (tương đương 37 triệu USD) thông qua phát hành trái phiếu xanh không đảm bảo kỳ hạn 5 năm.', '<div class=\"x11i5rnm xat24cr x1mh8g0r x1vvkbs xtlvy1s x126k92a\">\r\n<div dir=\"auto\">C&ocirc;ng ty cho biết v&ograve;ng g&acirc;y quỹ lần n&agrave;y đ&aacute;nh dấu đợt ph&aacute;t h&agrave;nh tr&aacute;i phiếu bằng đồng đ&ocirc; la Singapore tập trung v&agrave;o năng lượng sinh học đầu ti&ecirc;n ở ch&acirc;u &Aacute;. Thương vụ đ&atilde; được t&agrave;i trợ vượt mức sau khi Apeiron cho biết họ đ&atilde; nhận được sự quan t&acirc;m từ c&aacute;c nh&agrave; đầu tư chiến lược v&agrave; tổ chức.</div>\r\n</div>\r\n<div class=\"x11i5rnm xat24cr x1mh8g0r x1vvkbs xtlvy1s x126k92a\">\r\n<div dir=\"auto\">HSBC đ&oacute;ng vai tr&ograve; l&agrave; nh&agrave; quản l&yacute; dẫn đầu đợt ph&aacute;t h&agrave;nh tr&aacute;i phiếu.</div>\r\n</div>\r\n<div class=\"x11i5rnm xat24cr x1mh8g0r x1vvkbs xtlvy1s x126k92a\">\r\n<div dir=\"auto\">Chi tiết huy động vốn</div>\r\n</div>\r\n<div class=\"x11i5rnm xat24cr x1mh8g0r x1vvkbs xtlvy1s x126k92a\">\r\n<div dir=\"auto\">Số tiền huy động: 37 triệu đ&ocirc; la Mỹ</div>\r\n</div>\r\n<div class=\"x11i5rnm xat24cr x1mh8g0r x1vvkbs xtlvy1s x126k92a\">\r\n<div dir=\"auto\">&nbsp;</div>\r\n<div dir=\"auto\">&nbsp;</div>\r\n<div dir=\"auto\">&nbsp;</div>\r\n<div dir=\"auto\">&nbsp;</div>\r\n<div dir=\"auto\">&nbsp;</div>\r\n<div dir=\"auto\">&nbsp;</div>\r\n<div dir=\"auto\">&nbsp;</div>\r\n</div>\r\n<div class=\"x11i5rnm xat24cr x1mh8g0r x1vvkbs xtlvy1s x126k92a\">\r\n<div dir=\"auto\">Apeiron chuy&ecirc;n thu gom nhiều loại r&aacute;c thải n&ocirc;ng nghiệp v&agrave; thực phẩm kh&aacute;c nhau &ndash; bao gồm dầu ăn đ&atilde; qua sử dụng, mỡ động vật v&agrave; nước thải của nh&agrave; m&aacute;y dầu cọ &ndash; v&agrave; chuyển đổi ch&uacute;ng th&agrave;nh dầu diesel sinh học.</div>\r\n</div>\r\n<div class=\"x11i5rnm xat24cr x1mh8g0r x1vvkbs xtlvy1s x126k92a\">\r\n<div dir=\"auto\">Số tiền thu được từ việc ph&aacute;t h&agrave;nh tr&aacute;i phiếu sẽ được sử dụng cho vốn lưu động chung cũng như chi ti&ecirc;u vốn để mở rộng mạng lưới c&aacute;c điểm thu gom v&agrave; cơ sở xử l&yacute; dầu ăn đ&atilde; qua sử dụng của Apeiron Bioenergy.</div>\r\n</div>\r\n<div class=\"x11i5rnm xat24cr x1mh8g0r x1vvkbs xtlvy1s x126k92a\">\r\n<div dir=\"auto\">C&ocirc;ng ty đặt mục ti&ecirc;u tận dụng nhu cầu ng&agrave;y c&agrave;ng tăng tr&ecirc;n to&agrave;n cầu đối với dầu diesel t&aacute;i tạo, chẳng hạn như nhi&ecirc;n liệu h&agrave;ng kh&ocirc;ng bền vững, sử dụng nguy&ecirc;n liệu l&agrave;m từ chất thải sạch c&oacute; nguồn gốc từ dầu ăn đ&atilde; qua sử dụng. Theo Research &amp; Markets, c&ocirc;ng suất diesel t&aacute;i tạo to&agrave;n cầu cũng dự kiến sẽ đạt 14,63 triệu tấn v&agrave;o năm 2024, thể hiện tốc độ tăng trưởng k&eacute;p h&agrave;ng năm l&agrave; 21,33% kể từ năm 2020.</div>\r\n</div>\r\n<div class=\"x11i5rnm xat24cr x1mh8g0r x1vvkbs xtlvy1s x126k92a\">\r\n<div dir=\"auto\">Dầu ăn đ&atilde; qua sử dụng l&agrave; nguy&ecirc;n liệu ch&iacute;nh để sản xuất nhi&ecirc;n liệu sinh học của Apeiron, gi&uacute;p tiết kiệm đ&aacute;ng kể lượng kh&iacute; thải nh&agrave; k&iacute;nh. Tận dụng mạng lưới nh&agrave; cung cấp rộng khắp của m&igrave;nh ở ch&acirc;u &Aacute;, Apeiron c&oacute; kế hoạch hợp nhất c&aacute;c nguy&ecirc;n liệu nhi&ecirc;n liệu sinh học l&agrave;m từ chất thải trong khu vực, tự định vị m&igrave;nh l&agrave; trung t&acirc;m tập kết h&agrave;ng loạt c&aacute;c nguy&ecirc;n liệu n&agrave;y.</div>\r\n</div>\r\n<div class=\"x11i5rnm xat24cr x1mh8g0r x1vvkbs xtlvy1s x126k92a\">\r\n<div dir=\"auto\">&ldquo;Giao dịch n&agrave;y n&ecirc;u bật cam kết của ch&uacute;ng t&ocirc;i trong việc hỗ trợ c&aacute;c c&ocirc;ng ty đang trong giai đoạn tăng trưởng c&oacute; thể tạo điều kiện thuận lợi cho qu&aacute; tr&igrave;nh chuyển đổi sang nền kinh tế bền vững carbon th&ocirc;ng qua việc tăng cường cung cấp nhi&ecirc;n liệu sinh học thay thế c&oacute; h&agrave;m lượng carbon thấp&rdquo;, Sean Henderson, đồng gi&aacute;m đốc thị trường vốn nợ tại chi nh&aacute;nh ch&acirc;u &Aacute; &ndash; Th&aacute;i B&igrave;nh Dương của HSBC cho biết.</div>\r\n</div>\r\n<div class=\"x11i5rnm xat24cr x1mh8g0r x1vvkbs xtlvy1s x126k92a\">\r\n<div dir=\"auto\">Apeiron Bioenergy</div>\r\n<div dir=\"auto\">C&ocirc;ng ty được th&agrave;nh lập năm 2007 bởi Chris Chen.</div>\r\n</div>\r\n<div class=\"x11i5rnm xat24cr x1mh8g0r x1vvkbs xtlvy1s x126k92a\">\r\n<div dir=\"auto\">Nguồn: <a class=\"x1i10hfl xjbqb8w x6umtig x1b1mbwd xaqea5y xav7gou x9f619 x1ypdohk xt0psk2 xe8uvvx xdj266r x11i5rnm xat24cr x1mh8g0r xexx8yu x4uap5 x18d9i69 xkhd6sd x16tdsg8 x1hl2dhg xggy1nq x1a2a7pz xt0b8zv x1fey0fg\" tabindex=\"0\" role=\"link\" href=\"http://startupdongnai.gov.vn/tin-tuc-su-kien/apeiron-tru-so-tai-singapore-huy-dong-37-trieu-de-mo-rong-mang-luoi-nhien-lieu-sinh-hoc/?fbclid=IwAR2DahvLFstCUvCFpegPbuGZKQ-zNGGvylj2_abDlwW_Lhyzs-UJlg81VYs\" target=\"_blank\" rel=\"nofollow noopener\">http://startupdongnai.gov.vn/.../apeiron-tru-so-tai.../</a></div>\r\n<div dir=\"auto\"><a class=\"x1i10hfl xjbqb8w x6umtig x1b1mbwd xaqea5y xav7gou x9f619 x1ypdohk xt0psk2 xe8uvvx xdj266r x11i5rnm xat24cr x1mh8g0r xexx8yu x4uap5 x18d9i69 xkhd6sd x16tdsg8 x1hl2dhg xggy1nq x1a2a7pz xt0b8zv x1fey0fg\" tabindex=\"0\" role=\"link\" href=\"https://www.cgif-abmi.org/storage/2023/06/Apeiron_Press-Release_final.pdf?fbclid=IwAR2NtcLCukHpgAksUHGBJpQ6xvz0Yb2RibLGA8hZHOAQXFc-jfMWsc0_FiI\" target=\"_blank\" rel=\"nofollow noopener\">https://www.cgif-abmi.org/.../Apeiron_Press-Release_final...</a></div>\r\n</div>', '2023-08-10 22:11:51', '2023-08-10 22:13:53', 1, '', '', NULL, 'DRAFT', '', 'vi', NULL),
(1909, '20230814-142756-BhzN', 'https://apeironbioenergy.vn/images/posts/20230814-142756-BhzN/Green%20Creative%20Watercolor%20Stationery%20Document%20%20(1).png', 'thong-bao', 'THÔNG BÁO NGHỈ LỄ QUỐC KHÁNH VIỆT NAM 2023', 'thong-bao-nghi-le-quoc-khanh-viet-nam-2023', '', '<p><img src=\"/images/posts/20230814-142756-BhzN/Green%20Creative%20Watercolor%20Stationery%20Document%20.png\" alt=\"\" width=\"100%\" height=\"\" /></p>', '2023-08-14 14:31:13', '2023-08-24 17:03:59', 1, '', '', NULL, 'PUBLISH', '', 'vi', NULL),
(1910, '20230824-164606-FpVI', 'https://apeironbioenergy.vn/images/posts/quy%20trinh%20san%20xuat%20dau%20Diesel.jpg', 'tin-tuc', 'QUY TRÌNH SẢN XUẤT NGUYÊN LIỆU SINH HỌC DIESEL TỪ DẦU ĂN ĐÃ QUA SỬ DỤNG', 'quy-trinh-san-xuat-nguyen-lieu-sinh-hoc-diesel-tu-dau-an-da-qua-su-dung', 'Quy trình sản xuất nguyên liệu sinh học diesel từ dầu ăn đã qua sử dụng thường được gọi là quy trình chế biến dầu thải (used cooking oil) thành biodiesel. Dưới đây là một quy trình cơ bản để sản xuất biodiesel từ dầu ăn đã qua sử dụng', '<p><strong><img src=\"/images/posts/20230824-164606-FpVI/quy%20trinh%20san%20xuat%20dau%20Diesel.jpg\" alt=\"\" width=\"100%\" /></strong></p>\r\n<p><strong>BƯỚC</strong><strong> 1: THU GOM V&Agrave; XỬ L&Yacute; DẦU ĂN Đ&Atilde; QUA SỬ DỤNG </strong></p>\r\n<p>Thu gom dầu ăn đ&atilde; qua sử dụng từ c&aacute;c nh&agrave; h&agrave;ng, kh&aacute;ch sạn, cơ sở sản xuất thực phẩm, v&agrave; hộ gia đ&igrave;nh.</p>\r\n<p>L&agrave;m sạch dầu ăn đ&atilde; qua sử dụng để loại bỏ c&aacute;c tạp chất như thức ăn thừa v&agrave; c&aacute;c chất g&acirc;y &ocirc; nhiễm kh&aacute;c.</p>\r\n<p><strong>BƯỚC</strong><strong> 2: TIỀN XỬ L&Yacute; </strong></p>\r\n<p>Dầu ăn đ&atilde; qua sử dụng thường chứa nước v&agrave; tạp chất. Tiền xử l&yacute; bao gồm qu&aacute; tr&igrave;nh t&aacute;ch nước v&agrave; tạp chất khỏi dầu.</p>\r\n<p>C&aacute;c phương ph&aacute;p tiền xử l&yacute; c&oacute; thể bao gồm lọc, kết tủa, v&agrave; c&aacute;c quy tr&igrave;nh h&oacute;a học để loại bỏ tạp chất.</p>\r\n<p><strong>BƯỚC</strong><strong> 3: QU&Aacute;</strong><strong> TR&Igrave;NH CHẾ BIẾN</strong></p>\r\n<p>Quy tr&igrave;nh chế biến thường dựa tr&ecirc;n phản ứng ester h&oacute;a, trong đ&oacute; dầu ăn đ&atilde; qua sử dụng phản ứng với một loại cồn (thường l&agrave; methanol) v&agrave; một lượng nhỏ x&uacute;c t&aacute;c (catalyst) để tạo ra biodiesel v&agrave; glycerol.</p>\r\n<p>Phản ứng n&agrave;y tạo ra hai sản phẩm ch&iacute;nh: biodiesel (methyl ester) v&agrave; glycerol. Biodiesel c&oacute; thể t&aacute;ch ri&ecirc;ng khỏi glycerol.</p>\r\n<p><strong>BƯỚC</strong><strong> 4: T&Aacute;CH</strong><strong> BIODIESEL V&Agrave; GLYCEROL</strong></p>\r\n<p>Sau khi phản ứng ho&agrave;n th&agrave;nh, dầu biodiesel v&agrave; lớp glycerol t&aacute;ch ri&ecirc;ng nhau dựa tr&ecirc;n sự kh&aacute;c biệt về mật độ.</p>\r\n<p>Biodiesel sẽ nổi l&ecirc;n tr&ecirc;n lớp glycerol.</p>\r\n<p><strong>BƯỚC 5: L&Agrave;M</strong><strong> SẠCH V&Agrave; TH&Agrave;NH PHẨM </strong></p>\r\n<p>Biodiesel thu được sau qu&aacute; tr&igrave;nh t&aacute;ch lớp cần được l&agrave;m sạch để loại bỏ c&aacute;c tạp chất c&ograve;n lại v&agrave; c&aacute;c chất x&uacute;c t&aacute;c dư thừa.</p>\r\n<p>Qu&aacute; tr&igrave;nh l&agrave;m sạch v&agrave; tinh chế c&oacute; thể bao gồm lọc, rửa nước v&agrave; sử dụng hợp chất h&oacute;a học để loại bỏ tạp chất.</p>\r\n<p><strong>Bước 6: KIỂM</strong><strong> TRA CHẤT LƯỢNG V&Agrave; Đ&Oacute;NG TH&Agrave;NH PHẨM</strong></p>\r\n<p>Biodiesel sau khi đ&atilde; qua qu&aacute; tr&igrave;nh l&agrave;m sạch v&agrave; tinh chế cần được kiểm tra chất lượng để đảm bảo đ&aacute;p ứng c&aacute;c ti&ecirc;u chuẩn v&agrave; th&ocirc;ng số kỹ thuật.</p>\r\n<p>Nếu đạt y&ecirc;u cầu chất lượng, biodiesel c&oacute; thể được đ&oacute;ng chai hoặc đ&oacute;ng v&agrave;o c&aacute;c th&ugrave;ng chứa để sẵn s&agrave;ng b&aacute;n ra thị trường.</p>\r\n<p>Lưu &yacute; rằng quy tr&igrave;nh tr&ecirc;n chỉ l&agrave; một biểu đồ cơ bản, v&agrave; trong thực tế c&oacute; thể c&oacute; c&aacute;c biến thể v&agrave; quy tr&igrave;nh phức tạp hơn để đảm bảo chất lượng v&agrave; hiệu suất sản xuất tốt nhất.</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>', '2023-08-24 16:49:20', '2023-08-24 16:49:27', 1, '', '', NULL, 'PUBLISH', '', 'vi', NULL),
(1911, '20230827-163724-0FhX', 'https://apeironbioenergy.vn/images/posts/20230827-163724-0FhX/cove.png', 'tin-tuc', 'APEIRON BIOENERGY -CHÚNG TÔI LÀ AI? ????', 'apeiron-bioenergy-chung-toi-la-ai', 'Apeiron Bioenergy là công ty hàng đầu trong ngành năng lượng sinh học- có trụ sở tại Singapore với hai nhà máy lọc dầu hoạt động và mạng lưới 09 kho thu gom dầu ăn đã qua sử dụng, phủ rộng trên khắp lãnh thổ châu Á. Với hơn 15 năm hoạt động và phát triển, Apeiron Bioenergy đã thiết lập vị thế vững chắc trong hơn mười quốc gia và góp phần đáng kể vào việc hạn chế tác động tiêu cực của khí nhà kính đối với môi trường.', '<div class=\"x11i5rnm xat24cr x1mh8g0r x1vvkbs xtlvy1s x126k92a\">\r\n<div dir=\"auto\">\r\n<p><strong><img src=\"/images/posts/20230827-163724-0FhX/who%20we%20are.png\" alt=\"\" width=\"100%\" /></strong></p>\r\n<p><strong>Về Apeiron Bioenergy</strong></p>\r\n</div>\r\n<div dir=\"auto\">Apeiron Bioenergy l&agrave; c&ocirc;ng ty h&agrave;ng đầu trong ng&agrave;nh năng lượng sinh học- c&oacute; trụ sở tại Singapore với hai nh&agrave; m&aacute;y lọc dầu hoạt động v&agrave; mạng lưới 09 kho thu gom dầu ăn đ&atilde; qua sử dụng, phủ rộng tr&ecirc;n khắp l&atilde;nh thổ ch&acirc;u &Aacute;. Với hơn 15 năm hoạt động v&agrave; ph&aacute;t triển, Apeiron Bioenergy đ&atilde; thiết lập vị thế vững chắc trong hơn mười quốc gia v&agrave; g&oacute;p phần đ&aacute;ng kể v&agrave;o việc hạn chế t&aacute;c động ti&ecirc;u cực của kh&iacute; nh&agrave; k&iacute;nh đối với m&ocirc;i trường.</div>\r\n<div dir=\"auto\">&nbsp;</div>\r\n<div dir=\"auto\"><strong>G&oacute;p phần bảo vệ m&ocirc;i trường v&agrave; giảm thải nh&agrave; k&iacute;nh</strong></div>\r\n</div>\r\n<div class=\"x11i5rnm xat24cr x1mh8g0r x1vvkbs xtlvy1s x126k92a\">\r\n<div dir=\"auto\">Trong bối cảnh tăng cường nhận thức về t&igrave;nh trạng biến đổi kh&iacute; hậu v&agrave; &ocirc; nhiễm m&ocirc;i trường, việc t&igrave;m kiếm c&aacute;c giải ph&aacute;p bền vững để giảm thiểu t&aacute;c động của chất thải v&agrave; thải kh&iacute; nh&agrave; k&iacute;nh l&agrave; một ưu ti&ecirc;n h&agrave;ng đầu. Apeiron Bioenergy đ&atilde; đ&oacute;ng g&oacute;p quan trọng bằng c&aacute;ch giảm sự phụ thuộc to&agrave;n cầu v&agrave;o nhi&ecirc;n liệu h&oacute;a thạch th&ocirc;ng qua việc thu thập v&agrave; t&aacute;i chế dầu ăn cũ. T&iacute;ch luỹ hơn 600 triệu l&iacute;t dầu ăn trong giai đoạn từ 2017 đến nay, c&ocirc;ng ty đ&atilde; tạo ra t&aacute;c động t&iacute;ch cực đối với m&ocirc;i trường v&agrave; giảm lượng kh&iacute; thải carbon ước t&iacute;nh l&ecirc;n tới 1.8 triệu tấn.</div>\r\n<div dir=\"auto\">&nbsp;</div>\r\n</div>\r\n<div class=\"x11i5rnm xat24cr x1mh8g0r x1vvkbs xtlvy1s x126k92a\">\r\n<div dir=\"auto\"><strong>Gi&aacute; trị vượt trội</strong></div>\r\n<div dir=\"auto\">Apeiron Bioenergy tập trung v&agrave;o việc thu mua v&agrave; chế biến dầu ăn đ&atilde; qua sử dụng th&agrave;nh nguy&ecirc;n liệu sinh học diesel. Qua qu&aacute; tr&igrave;nh c&ocirc;ng nghệ ti&ecirc;n tiến, dầu ăn đ&atilde; qua sử dụng sẽ được xử l&yacute; v&agrave; tinh chế để tạo ra nguy&ecirc;n liệu sinh học diesel chất lượng cao, th&acirc;n thiện với m&ocirc;i trường. Điều n&agrave;y đồng nghĩa kh&ocirc;ng chỉ giảm thiểu lượng chất thải dầu mỡ g&acirc;y &ocirc; nhiễm m&ocirc;i trường m&agrave; c&ograve;n gi&uacute;p giảm thiểu lượng kh&iacute; nh&agrave; k&iacute;nh được sinh ra trong qu&aacute; tr&igrave;nh sản xuất v&agrave; sử dụng nhi&ecirc;n liệu.</div>\r\n</div>\r\n<div class=\"x11i5rnm xat24cr x1mh8g0r x1vvkbs xtlvy1s x126k92a\">\r\n<div dir=\"auto\">V&igrave; một h&agrave;nh tinh xanh v&agrave; sạch <span class=\"x3nfvp2 x1j61x8r x1fcty0u xdj266r xhhsvwb xat24cr xgzva0m xxymvpz xlup9mm x1kky2od\"><img src=\"https://static.xx.fbcdn.net/images/emoji.php/v9/tc0/1/16/1f30e.png\" alt=\"????\" width=\"16\" height=\"16\" /></span><span class=\"x3nfvp2 x1j61x8r x1fcty0u xdj266r xhhsvwb xat24cr xgzva0m xxymvpz xlup9mm x1kky2od\"><img src=\"https://static.xx.fbcdn.net/images/emoji.php/v9/tc0/1/16/1f30e.png\" alt=\"????\" width=\"16\" height=\"16\" /></span></div>\r\n<div dir=\"auto\"><a class=\"x1i10hfl xjbqb8w x6umtig x1b1mbwd xaqea5y xav7gou x9f619 x1ypdohk xt0psk2 xe8uvvx xdj266r x11i5rnm xat24cr x1mh8g0r xexx8yu x4uap5 x18d9i69 xkhd6sd x16tdsg8 x1hl2dhg xggy1nq x1a2a7pz xt0b8zv x1qq9wsj xo1l8bm\" tabindex=\"0\" role=\"link\" href=\"https://www.facebook.com/hashtag/apeironbioenergy?__eep__=6&amp;__cft__[0]=AZWuJcMxd_uZJWwF-0T0o-koBtZSoDO40GjXz5pVd7TgZ_yXyTdrwQTuvJDgMHielELMJeoLOu-xHOjfQRO4ydlBkYOMSE3KYhIGV7s-9vD8cwWkPFiAV0aypHwgeafaLnH8m62a-l1zgm_bchcTPegmVgA5lsRlu0cIOkM5s_iKqHhddmb0h37_oQUUiMfam1U&amp;__tn__=*NK-R\">#apeironbioenergy</a> <a class=\"x1i10hfl xjbqb8w x6umtig x1b1mbwd xaqea5y xav7gou x9f619 x1ypdohk xt0psk2 xe8uvvx xdj266r x11i5rnm xat24cr x1mh8g0r xexx8yu x4uap5 x18d9i69 xkhd6sd x16tdsg8 x1hl2dhg xggy1nq x1a2a7pz xt0b8zv x1qq9wsj xo1l8bm\" tabindex=\"0\" role=\"link\" href=\"https://www.facebook.com/hashtag/gogreen?__eep__=6&amp;__cft__[0]=AZWuJcMxd_uZJWwF-0T0o-koBtZSoDO40GjXz5pVd7TgZ_yXyTdrwQTuvJDgMHielELMJeoLOu-xHOjfQRO4ydlBkYOMSE3KYhIGV7s-9vD8cwWkPFiAV0aypHwgeafaLnH8m62a-l1zgm_bchcTPegmVgA5lsRlu0cIOkM5s_iKqHhddmb0h37_oQUUiMfam1U&amp;__tn__=*NK-R\">#gogreen</a> <a class=\"x1i10hfl xjbqb8w x6umtig x1b1mbwd xaqea5y xav7gou x9f619 x1ypdohk xt0psk2 xe8uvvx xdj266r x11i5rnm xat24cr x1mh8g0r xexx8yu x4uap5 x18d9i69 xkhd6sd x16tdsg8 x1hl2dhg xggy1nq x1a2a7pz xt0b8zv x1qq9wsj xo1l8bm\" tabindex=\"0\" role=\"link\" href=\"https://www.facebook.com/hashtag/uco?__eep__=6&amp;__cft__[0]=AZWuJcMxd_uZJWwF-0T0o-koBtZSoDO40GjXz5pVd7TgZ_yXyTdrwQTuvJDgMHielELMJeoLOu-xHOjfQRO4ydlBkYOMSE3KYhIGV7s-9vD8cwWkPFiAV0aypHwgeafaLnH8m62a-l1zgm_bchcTPegmVgA5lsRlu0cIOkM5s_iKqHhddmb0h37_oQUUiMfam1U&amp;__tn__=*NK-R\">#UCO</a> <a class=\"x1i10hfl xjbqb8w x6umtig x1b1mbwd xaqea5y xav7gou x9f619 x1ypdohk xt0psk2 xe8uvvx xdj266r x11i5rnm xat24cr x1mh8g0r xexx8yu x4uap5 x18d9i69 xkhd6sd x16tdsg8 x1hl2dhg xggy1nq x1a2a7pz xt0b8zv x1qq9wsj xo1l8bm\" tabindex=\"0\" role=\"link\" href=\"https://www.facebook.com/hashtag/biodiesel?__eep__=6&amp;__cft__[0]=AZWuJcMxd_uZJWwF-0T0o-koBtZSoDO40GjXz5pVd7TgZ_yXyTdrwQTuvJDgMHielELMJeoLOu-xHOjfQRO4ydlBkYOMSE3KYhIGV7s-9vD8cwWkPFiAV0aypHwgeafaLnH8m62a-l1zgm_bchcTPegmVgA5lsRlu0cIOkM5s_iKqHhddmb0h37_oQUUiMfam1U&amp;__tn__=*NK-R\">#Biodiesel</a> <a class=\"x1i10hfl xjbqb8w x6umtig x1b1mbwd xaqea5y xav7gou x9f619 x1ypdohk xt0psk2 xe8uvvx xdj266r x11i5rnm xat24cr x1mh8g0r xexx8yu x4uap5 x18d9i69 xkhd6sd x16tdsg8 x1hl2dhg xggy1nq x1a2a7pz xt0b8zv x1qq9wsj xo1l8bm\" tabindex=\"0\" role=\"link\" href=\"https://www.facebook.com/hashtag/recycle?__eep__=6&amp;__cft__[0]=AZWuJcMxd_uZJWwF-0T0o-koBtZSoDO40GjXz5pVd7TgZ_yXyTdrwQTuvJDgMHielELMJeoLOu-xHOjfQRO4ydlBkYOMSE3KYhIGV7s-9vD8cwWkPFiAV0aypHwgeafaLnH8m62a-l1zgm_bchcTPegmVgA5lsRlu0cIOkM5s_iKqHhddmb0h37_oQUUiMfam1U&amp;__tn__=*NK-R\">#recycle</a> <a class=\"x1i10hfl xjbqb8w x6umtig x1b1mbwd xaqea5y xav7gou x9f619 x1ypdohk xt0psk2 xe8uvvx xdj266r x11i5rnm xat24cr x1mh8g0r xexx8yu x4uap5 x18d9i69 xkhd6sd x16tdsg8 x1hl2dhg xggy1nq x1a2a7pz xt0b8zv x1qq9wsj xo1l8bm\" tabindex=\"0\" role=\"link\" href=\"https://www.facebook.com/hashtag/apeironbioenergyvietnam?__eep__=6&amp;__cft__[0]=AZWuJcMxd_uZJWwF-0T0o-koBtZSoDO40GjXz5pVd7TgZ_yXyTdrwQTuvJDgMHielELMJeoLOu-xHOjfQRO4ydlBkYOMSE3KYhIGV7s-9vD8cwWkPFiAV0aypHwgeafaLnH8m62a-l1zgm_bchcTPegmVgA5lsRlu0cIOkM5s_iKqHhddmb0h37_oQUUiMfam1U&amp;__tn__=*NK-R\">#apeironbioenergyvietnam</a></div>\r\n</div>', '2023-08-27 16:42:52', '2024-01-13 15:47:40', 1, '', '', '', 'PUBLISH', '', 'vi', NULL),
(1912, '20230906-154805-UrAK', 'https://apeironbioenergy.vn/images/posts/question.png', 'tin-tuc', 'MỌI NGƯỜI NGHĨ GÌ VỀ VIỆC THU GOM DẦU ĂN ĐÃ QUA SỬ DỤNG Ở VIỆT NAM? ', 'moi-nguoi-nghi-gi-ve-viec-thu-gom-dau-an-da-qua-su-dung-o-viet-nam', ' “Họ thu gom dầu ăn để bán lại cho nơi làm dầu ăn bẩn lề đường “ \r\n“Họ mua về để bán lại ra thị trường” \r\n“Làm gì có việc mua về để sản xuất nguyên liệu sinh học” \r\n', '<p><img src=\"/images/posts/20230906-154805-UrAK/question.png\" alt=\"\" width=\"100%\" /></p>\r\n<p>&nbsp;&ldquo;Họ thu gom dầu ăn để b&aacute;n lại cho nơi l&agrave;m dầu ăn bẩn lề đường &ldquo;</p>\r\n<p>&ldquo;Họ mua về để b&aacute;n lại ra thị trường&rdquo;</p>\r\n<p>&ldquo;L&agrave;m g&igrave; c&oacute; việc mua về để sản xuất nguy&ecirc;n liệu sinh học&rdquo;</p>\r\n<p>Đ&acirc;y l&agrave; những comment t&ocirc;i đọc được ở c&aacute;c group tr&ecirc;n Facebook. Dường như việc thu gom dầu ăn cũ c&oacute; c&aacute;i nh&igrave;n chưa mấy &ldquo;s&aacute;ng sủa&rdquo; &nbsp;v&agrave; sai lệch so với mục đ&iacute;ch thật của việc thu gom l&agrave; để xuất khẩu l&agrave;m nguy&ecirc;n liệu sinh học Diesel sử dụng cho c&aacute;c phương tiện di chuyển như m&aacute;y bay, xe &ocirc; t&ocirc; , &hellip;</p>\r\n<p>Thu gom dầu ăn cũ đ&atilde; qua sử dụng l&agrave; một kh&aacute;i niệm mới mẻ đối với nhiều b&agrave; nội trợ tại Việt Nam, trong khi c&aacute;c hoạt động thu gom kh&aacute;c như pin cũ đổi c&acirc;y, s&aacute;ch cũ đổi qu&agrave;, v&agrave; t&aacute;i chế nhựa đ&atilde; trở n&ecirc;n phổ biến hơn. Một số người thậm ch&iacute; c&oacute; quan điểm sai lệch về mục đ&iacute;ch thu gom dầu ăn, cho rằng n&oacute; chỉ để b&aacute;n lại cho nơi l&agrave;m dầu ăn bẩn cho qu&aacute;n lề đường hoặc mục đ&iacute;ch tư lợi c&aacute; nh&acirc;n.</p>\r\n<p>&nbsp;</p>\r\n<p>Những quan điểm n&agrave;y kh&ocirc;ng phản &aacute;nh đ&uacute;ng mục ti&ecirc;u thực sự của việc thu gom dầu ăn cũ, l&agrave; để chuyển ch&uacute;ng th&agrave;nh nguy&ecirc;n liệu sinh học Diesel d&ugrave;ng cho c&aacute;c phương tiện di chuyển như m&aacute;y bay v&agrave; xe &ocirc; t&ocirc;. Thực tế, việc thu gom v&agrave; t&aacute;i chế dầu ăn cũ c&oacute; lợi cho m&ocirc;i trường v&agrave; kinh tế. N&oacute; gi&uacute;p giảm thiểu lượng dầu ăn cũ xả thải một c&aacute;ch kh&ocirc;ng đ&uacute;ng c&aacute;ch v&agrave; gi&uacute;p t&aacute;i sử dụng t&agrave;i nguy&ecirc;n qu&yacute; b&aacute;u.</p>\r\n<p>&nbsp;</p>\r\n<p>Tuy nhi&ecirc;n, ở Việt Nam, việc thu gom dầu ăn cũ vẫn đang gặp nhiều kh&oacute; khăn. Một số người kh&ocirc;ng biết c&aacute;ch thu gom v&agrave; lưu trữ dầu ăn cũ một c&aacute;ch an to&agrave;n, dẫn đến xả thải kh&ocirc;ng đ&uacute;ng c&aacute;ch v&agrave; c&oacute; thể g&acirc;y hại cho m&ocirc;i trường v&agrave; sức khỏe con người.</p>\r\n<p>&nbsp;</p>\r\n<p>Kh&aacute;c với Việt Nam, c&aacute;c nước như Singapore, Nhật Bản v&agrave; một số nước Ch&acirc;u &Acirc;u lu&ocirc;n đặt m&ocirc;i trường v&agrave; việc xử l&yacute; chất thải l&ecirc;n h&agrave;ng đầu. Họ đ&atilde; th&agrave;nh c&ocirc;ng trong việc x&acirc;y dựng cộng đồng thu gom dầu ăn cũ v&agrave; biến n&oacute; th&agrave;nh một nguồn nguy&ecirc;n liệu c&oacute; gi&aacute; trị cao để sản xuất nguy&ecirc;n liệu sinh học Diesel. Dầu ăn cũ được coi như một loại t&agrave;i sản qu&yacute; b&aacute;u v&agrave; mang lại lợi &iacute;ch lớn cho m&ocirc;i trường v&agrave; nền kinh tế.</p>\r\n<p>&nbsp;</p>\r\n<p>Trong giai đoạn tiếp theo, Apeiron Bioenergy mong muốn hợp t&aacute;c chặt chẽ với tất cả c&aacute;c b&ecirc;n, bao gồm c&aacute;c doanh nghiệp, cơ quan, tổ chức, c&aacute; nh&acirc;n, v&agrave; c&aacute;c dự &aacute;n m&ocirc;i trường cũng như c&aacute;c hoạt động t&aacute;i chế bền vững n&oacute;i ri&ecirc;ng. Ch&uacute;ng t&ocirc;i cam kết đồng h&agrave;nh mạnh mẽ với cộng đồng để bảo vệ m&ocirc;i trường v&agrave; th&uacute;c đẩy c&aacute;c giải ph&aacute;p bền vững.</p>\r\n<p>Ch&uacute;ng t&ocirc;i hy vọng c&oacute; thể tạo ra một sự tham gia t&iacute;ch cực từ tất cả mọi người để x&acirc;y dựng một tương lai tốt đẹp hơn cho h&agrave;nh tinh n&agrave;y. Ch&uacute;ng t&ocirc;i tin rằng th&ocirc;ng qua sự đo&agrave;n kết v&agrave; hợp t&aacute;c, ch&uacute;ng ta c&oacute; thể đạt được mục ti&ecirc;u bảo vệ m&ocirc;i trường v&agrave; đảm bảo sự bền vững cho tất cả c&aacute;c thế hệ tới.</p>', '2023-09-06 15:52:14', NULL, 1, '', '', NULL, 'PUBLISH', '', 'vi', NULL),
(1913, '26pmvw', NULL, NULL, 'New Post Title here...', 'new-post-title-here', NULL, NULL, '2024-01-13 14:25:08', NULL, 1, NULL, NULL, NULL, 'DRAFT', NULL, 'vi', NULL),
(1914, '27wbpq', NULL, NULL, 'New Post Title here...', 'new-post-title-here-2', NULL, NULL, '2024-01-13 14:25:39', NULL, 1, NULL, NULL, NULL, 'DRAFT', NULL, 'vi', NULL),
(1915, '43cbip', '', NULL, 'New Post Title here...', 'new-post-title-here-3', '', '', '2024-01-13 14:26:19', '2024-01-13 14:32:55', 1, '', '', NULL, 'DRAFT', '', 'vi', NULL),
(1916, '79nxvu', 'http://localhost:9999/images/posts/79nxvu/post1.jpg', NULL, 'New Post Title here...', 'new-post-title-here-4', '', '', '2024-01-13 14:37:10', '2024-01-13 14:47:43', 1, '', '', 'http://localhost:9999/images/posts/79nxvu/post2.jpg', 'DRAFT', '', 'vi', NULL),
(1917, '53cvfo', '', NULL, 'New Post Title here...', 'new-post-title-here-5', '', '', '2024-01-13 15:47:23', '2024-01-13 15:47:29', 1, '', '', '', 'DRAFT', '', 'vi', NULL),
(1918, '76tiec', NULL, NULL, 'New Post Title here...', 'new-post-title-here-6', NULL, NULL, '2024-01-14 08:07:34', '2024-01-14 08:07:34', 1, NULL, NULL, NULL, 'DRAFT', NULL, 'vi', NULL),
(1919, '54ckgj', '', NULL, 'New Post Title here...', 'new-post-title-here-7', '', '', '2024-01-14 08:29:11', '2024-01-15 15:16:31', 1, '', '', '', 'DRAFT', '', 'vi', NULL),
(1920, '54ckgj', '', NULL, 'New Post Title here...', 'new-post-title-here-7', '', '', '2024-01-15 07:49:11', '2024-01-15 15:15:37', 1, '', '', '', 'PUBLISH', '', 'en', NULL),
(1921, '76tiec', NULL, NULL, 'New Post Title here...', 'new-post-title-here-6', '', '', '2024-01-15 07:51:08', '2024-01-15 07:51:08', 1, '', '', NULL, 'PUBLISH', NULL, 'en', NULL),
(1922, '20230827-163724-0FhX', '', NULL, 'APEIRON BIOENERGY -CHÚNG TÔI LÀ AI? ????', 'apeiron-bioenergy-chung-toi-la-ai', '', '', '2024-01-15 07:52:37', '2024-01-15 08:44:29', 1, '', '', '', 'PUBLISH', '', 'khmer', NULL),
(1923, '79vkzr', NULL, NULL, 'New Post Title here...', 'new-post-title-here-8', NULL, NULL, '2024-01-15 08:45:16', '2024-01-15 08:45:16', 1, NULL, NULL, NULL, 'DRAFT', NULL, 'vi', NULL),
(1924, '70pteb', NULL, NULL, 'New Post Title here...', 'new-post-title-here-9', NULL, NULL, '2024-01-15 14:52:32', '2024-01-15 14:52:32', 1, NULL, NULL, NULL, 'DRAFT', NULL, 'vi', NULL),
(1925, '12lzpf', NULL, NULL, 'New Post Title here...', 'new-post-title-here-10', NULL, NULL, '2024-01-15 15:21:02', '2024-01-15 15:21:02', 1, NULL, NULL, NULL, 'DRAFT', NULL, 'vi', NULL),
(1926, '71sczl', NULL, NULL, 'New Post Title here...', 'new-post-title-here-11', NULL, NULL, '2024-01-15 15:23:39', '2024-01-15 15:23:39', 1, NULL, NULL, NULL, 'DRAFT', NULL, 'vi', NULL),
(1927, '91lpyi', NULL, NULL, 'New Post Title here...', 'new-post-title-here-12', NULL, NULL, '2024-01-15 15:54:42', '2024-01-15 15:54:42', 1, NULL, NULL, NULL, 'DRAFT', NULL, 'vi', NULL),
(1928, '98yikp', '', NULL, 'New Post Title here...', 'new-post-title-here-13', '', '', '2024-01-15 16:41:06', '2024-01-16 08:40:22', 1, '', '', '', 'DRAFT', '', 'vi', NULL),
(1929, '41hjao', NULL, NULL, 'New Post Title here...', 'new-post-title-here-14', NULL, NULL, '2024-01-16 08:37:48', '2024-01-16 08:37:48', 1, NULL, NULL, NULL, 'DRAFT', NULL, 'vi', NULL),
(1930, '98yikp', NULL, NULL, 'New Post Title here...', 'new-post-title-here-13', '', '', '2024-01-16 09:49:39', '2024-01-16 09:49:39', 1, '', '', NULL, 'PUBLISH', NULL, 'en', NULL),
(1931, '98yikp', '', 'xxxxxxx', 'New Post Title here...', 'new-post-title-here-13', '', '', '2024-01-16 09:49:56', '2024-01-16 16:01:37', 1, '', '', '', 'DRAFT', '', 'khmer', NULL),
(1933, '41hjao', '', 'cccccccccccc', 'New Post Title here...', 'new-post-title-here-14', '', '', '2024-01-16 16:06:47', '2024-01-16 16:06:53', 1, '', '', '', 'PUBLISH', '', 'en', NULL),
(1934, '11rbtj', NULL, NULL, 'New Post Title here...', 'new-post-title-here-15', NULL, NULL, '2024-01-16 16:09:47', '2024-01-16 16:09:47', 1, NULL, NULL, NULL, 'DRAFT', NULL, 'vi', NULL),
(1935, '36unxy', '', 'tin-tuc', 'New Post Title here...', 'new-post-title-here-16', '', '', '2024-01-16 16:10:05', '2024-01-16 16:32:55', 1, '', '', '', 'DRAFT', 'tag-1;tag-3', 'vi', NULL),
(1936, '36unxy', '', 'this-is-english', 'New Post Title here...', 'new-post-title-here-16', '', '', '2024-01-16 16:10:43', '2024-01-16 16:25:52', 1, '', '', '', 'PUBLISH', 'tag-1;tag-2', 'en', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `post_documents`
--

DROP TABLE IF EXISTS `post_documents`;
CREATE TABLE IF NOT EXISTS `post_documents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `file_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `file_extension` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `file_size` float DEFAULT NULL,
  `summary` text COLLATE utf8_unicode_ci,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `post_documents`
--

INSERT INTO `post_documents` (`id`, `pid`, `name`, `url`, `file_name`, `file_extension`, `file_size`, `summary`, `date_created`, `user_created`) VALUES
(2, 4, 'xxxx', '4e00364886ba63c506cb9ea6888ffa8b.pdf', '[Nguyen Trinh] Quasoft Quotation (1).pdf', 'pdf', 586302, '', '2023-07-27 09:46:40', 1),
(3, 4, 'ddd', '49a2cf59b2fafed4a952d97561cb159d.xlsx', '_tinChi.xlsx', 'xlsx', 12009, '', '2023-07-27 13:46:06', 1),
(9, 4, 'test', '1e1848cc61ce6f23004dc03bcdfb7a33.xlsx', 'Book1.xlsx', 'xlsx', 71423, '', '2023-08-08 14:47:02', 1);

-- --------------------------------------------------------

--
-- Table structure for table `post_images`
--

DROP TABLE IF EXISTS `post_images`;
CREATE TABLE IF NOT EXISTS `post_images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `img_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `img_extension` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `img_size` float DEFAULT NULL,
  `img_wh` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `summary` text COLLATE utf8_unicode_ci,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `post_images`
--

INSERT INTO `post_images` (`id`, `pid`, `name`, `url`, `img_name`, `img_extension`, `img_size`, `img_wh`, `summary`, `date_created`, `user_created`) VALUES
(60, 4, '', 'ed3157a0407910d797205eb21ff9a536.png', 'fubusta_lines_qr_code_192720766.png', 'png', 318, NULL, '', '2023-07-27 09:46:55', 1),
(65, 4, '', '6c2b00941d0b18faa721d2c510164c68.jpg', 'tuyendung.jpg', 'jpg', 83283, NULL, '', '2023-08-08 14:46:49', 1);

-- --------------------------------------------------------

--
-- Table structure for table `post_types`
--

DROP TABLE IF EXISTS `post_types`;
CREATE TABLE IF NOT EXISTS `post_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `enable_images` tinyint(1) DEFAULT NULL,
  `enable_documents` tinyint(1) DEFAULT NULL,
  `enable_cover` tinyint(1) DEFAULT NULL,
  `enable_seo` tinyint(1) DEFAULT NULL,
  `enable_summary` tinyint(1) DEFAULT NULL,
  `enable_content` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
CREATE TABLE IF NOT EXISTS `settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `site_logo` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `site_logo_small` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `site_copyright` text COLLATE utf8_unicode_ci NOT NULL,
  `site_source` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `top_text` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `top_email` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `top_hotline` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `site_copyright_en` text COLLATE utf8_unicode_ci,
  `site_source_en` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `top_text_en` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `text_homepage` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `map` text COLLATE utf8_unicode_ci,
  `showcase_text` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `showcase_text_en` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `showcase_title` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `showcase_title_en` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `showcase_summary` text COLLATE utf8_unicode_ci,
  `showcase_summary_en` text COLLATE utf8_unicode_ci,
  `branches_text` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `branches_text_en` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `branches_title` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `branches_title_en` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `branches_summary` text COLLATE utf8_unicode_ci,
  `branches_summary_en` text COLLATE utf8_unicode_ci,
  `branches_page_name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `branches_page_name_en` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `branches_page_seo_title` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `branches_page_seo_description` text COLLATE utf8_unicode_ci,
  `branches_fist_content` text COLLATE utf8_unicode_ci,
  `branches_fist_content_en` text COLLATE utf8_unicode_ci,
  `branches_fist_image` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `branches_show_default` tinyint(1) DEFAULT NULL,
  `service_text` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `service_text_en` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `service_title` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `service_title_en` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `service_summary` text COLLATE utf8_unicode_ci,
  `service_summary_en` text COLLATE utf8_unicode_ci,
  `service_image` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `show_service_image` tinyint(1) DEFAULT NULL,
  `about_text` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `about_text_en` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `about_title` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `about_title_en` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `about_summary1` text COLLATE utf8_unicode_ci,
  `about_summary1_en` text COLLATE utf8_unicode_ci,
  `about_summary2` text COLLATE utf8_unicode_ci,
  `about_summary2_en` text COLLATE utf8_unicode_ci,
  `about_fact` text COLLATE utf8_unicode_ci,
  `about_fact_en` text COLLATE utf8_unicode_ci,
  `about_image` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `about2_title` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `about2_title_en` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `about2_summary` text COLLATE utf8_unicode_ci,
  `about2_summary_en` text COLLATE utf8_unicode_ci,
  `about2_image` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `about3_text` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `about3_text_en` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `about3_content` text COLLATE utf8_unicode_ci,
  `about3_content_en` text COLLATE utf8_unicode_ci,
  `contact_text` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact_text_en` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact_title` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact_title_en` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact_content` text COLLATE utf8_unicode_ci,
  `contact_content_en` text COLLATE utf8_unicode_ci,
  `show_index_block` tinyint(1) DEFAULT NULL,
  `site_index_block_1` text COLLATE utf8_unicode_ci,
  `site_index_block_2` text COLLATE utf8_unicode_ci,
  `site_index_block_1_en` text COLLATE utf8_unicode_ci,
  `site_index_block_2_en` text COLLATE utf8_unicode_ci,
  `site_index_bg_map` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `site_index_bg_blog` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `site_title` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `site_description` text COLLATE utf8_unicode_ci,
  `number_post_trending` tinyint(4) DEFAULT NULL,
  `number_post_catalog_home` tinyint(4) DEFAULT NULL,
  `number_post_per_page` tinyint(4) DEFAULT NULL,
  `number_post_like_in_news` tinyint(4) DEFAULT NULL,
  `show_cover_after_summary` tinyint(4) DEFAULT NULL,
  `sustainability_title` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sustainability_title_en` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sustainability_content` text COLLATE utf8_unicode_ci,
  `sustainability_content_en` text COLLATE utf8_unicode_ci,
  `sustainability_seo_title` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sustainability_seo_description` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `site_name`, `site_logo`, `site_logo_small`, `site_copyright`, `site_source`, `top_text`, `top_email`, `top_hotline`, `site_copyright_en`, `site_source_en`, `top_text_en`, `text_homepage`, `map`, `showcase_text`, `showcase_text_en`, `showcase_title`, `showcase_title_en`, `showcase_summary`, `showcase_summary_en`, `branches_text`, `branches_text_en`, `branches_title`, `branches_title_en`, `branches_summary`, `branches_summary_en`, `branches_page_name`, `branches_page_name_en`, `branches_page_seo_title`, `branches_page_seo_description`, `branches_fist_content`, `branches_fist_content_en`, `branches_fist_image`, `branches_show_default`, `service_text`, `service_text_en`, `service_title`, `service_title_en`, `service_summary`, `service_summary_en`, `service_image`, `show_service_image`, `about_text`, `about_text_en`, `about_title`, `about_title_en`, `about_summary1`, `about_summary1_en`, `about_summary2`, `about_summary2_en`, `about_fact`, `about_fact_en`, `about_image`, `about2_title`, `about2_title_en`, `about2_summary`, `about2_summary_en`, `about2_image`, `about3_text`, `about3_text_en`, `about3_content`, `about3_content_en`, `contact_text`, `contact_text_en`, `contact_title`, `contact_title_en`, `contact_content`, `contact_content_en`, `show_index_block`, `site_index_block_1`, `site_index_block_2`, `site_index_block_1_en`, `site_index_block_2_en`, `site_index_bg_map`, `site_index_bg_blog`, `site_title`, `site_description`, `number_post_trending`, `number_post_catalog_home`, `number_post_per_page`, `number_post_like_in_news`, `show_cover_after_summary`, `sustainability_title`, `sustainability_title_en`, `sustainability_content`, `sustainability_content_en`, `sustainability_seo_title`, `sustainability_seo_description`) VALUES
(1, 'Apeiron Bioenergy', 'http://localhost:9999/images/posts/_default/logo%20(1).png', 'http://localhost:9999/images/posts/_default/favicon.png', '© Apeiron Bioenergy (Vietnam) 2022. ', 'All Rights Reserved.', ' <i class=\"far fa-clock text-primary me-2\"></i>Giờ làm việc từ thứ Hai đến thứ Bảy : 6.00 am - 17.00 pm ', 'hung.nguyen@apeironbioenergy.com', '+84977240268', '© Apeiron Bioenergy (Vietnam) 2022. ', 'All Rights Reserved.', ' <i class=\"far fa-clock text-primary me-2\"></i>Opening Hours: Mon - Tues : 6.00 am - 10.00 pm, Sunday Closed ', 'Trang chủ', 'Kho Bình Dương|https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d5723.825837906647!2d106.77691103005164!3d10.890222031753956!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3174d75fb25e520d%3A0x869bfd7c0b43eca4!2sC%C3%B4ng%20ty%20TNHH%20APEIRON%20BIOENERGY%20(Vi%E1%BB%87t%20Nam)!5e0!3m2!1sen!2s!4v1681005437821!5m2!1sen!2s||Kho Cần Thơ|https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3927.693039920593!2d105.687917!3d10.1241926!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x31a0851a2a478199%3A0x18bd88ce74f3f82!2sKho%20C%E1%BA%A7n%20Th%C6%A1-%20C%C3%B4ng%20ty%20Apeiron%20Bioenergy%20(%20Viet%20Nam)!5e0!3m2!1sen!2s!4v1681006199837!5m2!1sen!2s||Kho Hà Nội|https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3727.7535732850815!2d105.8643875!3d20.8819806!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3135b3ab78134ba1%3A0xb3a30b90ccd5f0e3!2sKho%20H%C3%A0%20N%E1%BB%99i-%20CTY%20TNHH%20APEIRON%20BIOENERGY%20(VI%E1%BB%86T%20NAM)!5e0!3m2!1sen!2s!4v1681007386542!5m2!1sen!2s', 'Nhà máy của chúng tôi', 'Showcase', 'Hình ảnh nhà máy của Apeiron Bioenergy tại Việt Nam', 'Image of Apeiron Bioenergy\'s factory in Vietnam', 'Công ty chúng tôi đầu tư các nhà máy với quy trình xử lý nghiêm ngặt, theo chuẩn của quốc tế và thân thiện với môi trường', 'Our company has a factory with a strict processing procedure that meets international standards and is environmentally friendly.', 'Văn phòng và Chi nhánh', 'Offices and Branches', 'Một viễn cảnh toàn cầu', 'A Global Perspective', 'Chúng tôi có trụ sở tại Singapore và hoạt động hai nhà máy lọc dầu cùng chín kho thu gom ở khắp châu Á. Sự mở rộng chiều dọc và tích hợp vào thị trường năng lượng sinh học đã giúp chúng tôi kiểm soát toàn bộ chuỗi cung ứng và cung cấp những giải pháp tốt hơn cho khách hàng.', 'Headquartered in Singapore, we operate two refineries and nine collection warehouses across Asia. Our vertical and horizontal expansion and integration into bioenergy markets has enabled us to gain better control over the entire supply chain, thereby providing more desirable solutions for our clients.', 'Chi Nhánh Toàn Cầu', 'Global Presence', '', '', '<h2>Trụ sở ch&iacute;nh</h2>\r\n<span style=\"font-size: 18pt;\">Singapore<br /><br /></span>\r\n<h2>Văn ph&ograve;ng chi nh&aacute;nh</h2>\r\n<ol class=\"list\" role=\"list\">\r\n<li class=\"list-item\"><span style=\"font-size: 14pt;\">China</span></li>\r\n<li class=\"list-item-2\"><span style=\"font-size: 14pt;\">Indonesia</span></li>\r\n<li class=\"list-item-3\"><span style=\"font-size: 14pt;\">Japan</span></li>\r\n<li class=\"list-item-3\"><span style=\"font-size: 14pt;\">Malaysia</span></li>\r\n<li class=\"list-item-3\"><span style=\"font-size: 14pt;\">Philippines</span></li>\r\n<li class=\"list-item-3\"><span style=\"font-size: 14pt;\">Thailand</span></li>\r\n<li class=\"list-item-3\"><span style=\"font-size: 14pt;\">United Arab Emirates</span></li>\r\n<li class=\"list-item-3\"><span style=\"font-size: 14pt;\">Vietnam</span></li>\r\n</ol>', '<h2>Head Office</h2>\r\n<span style=\"font-size: 14pt;\">Singapore<br /><br /></span>\r\n<h2>Branch Offices</h2>\r\n<ol class=\"list\" role=\"list\">\r\n<li><span style=\"font-size: 14pt;\">Vietnam</span></li>\r\n<li><span style=\"font-size: 14pt;\">China</span></li>\r\n<li class=\"list-item-2\"><span style=\"font-size: 14pt;\">Indonesia</span></li>\r\n<li class=\"list-item-3\"><span style=\"font-size: 14pt;\">Japan</span></li>\r\n<li class=\"list-item-3\"><span style=\"font-size: 14pt;\">Malaysia</span></li>\r\n<li class=\"list-item-3\"><span style=\"font-size: 14pt;\">Philippines</span></li>\r\n<li class=\"list-item-3\"><span style=\"font-size: 14pt;\">Thailand</span></li>\r\n<li class=\"list-item-3\"><span style=\"font-size: 14pt;\">United Arab Emirates</span></li>\r\n<li class=\"list-item-3\"><span style=\"font-size: 14pt;\">Cambodia</span></li>\r\n</ol>', 'https://apeironbioenergy.vn/images/posts/_services/map.png', 1, 'Sản phẩm của chúng tôi', 'Products', 'Nguồn nguyên liệu bền vững', 'The Source of Sustainable Feedstocks', 'Được tích hợp hoàn toàn vào toàn bộ chuỗi cung ứng, chúng tôi trực tiếp tìm  và thu gom chất thải trong các dự án thượng nguồn và có thể linh hoạt sử dụng chúng trong các dự án hạ nguồn của chúng tôi.\r\n\r\nCác sản phẩm của chúng tôi bao gồm dầu ăn đã qua sử dụng, nước thải của nhà máy sản  dầu cọ, metyl este từ dầu ăn đã qua sử dụng, glycerin thô và các sản phẩm khác.', 'Fully integrated into the entire supply chain, we directly source and collect wastes in upstream projects and have the flexibility to use them in our downstream projects.\r\n\r\nOur products include used cooking oil, palm oil mill effluent, used cooking oil methyl ester, crude glycerin, and other products.', 'https://apeironbioenergy.vn/images/posts/_services/2155d467c6451c1b4554.jpg', 0, 'Về chúng tôi', 'About Us', 'Công ty hàng đầu thế giới về năng lượng sinh học', 'Leading Global Player in Bioenergy', 'Apeiron Bioenergy là công ty toàn cầu tích hợp hàng đầu trong toàn bộ chuỗi sản phẩm năng lượng sinh học từ nguyên liệu đầu vào đến sản phẩm cuối cùng và phụ phẩm.', 'Apeiron Bioenergy is a leading integrated global player in the entire chain of bioenergy products from feedstock to the end and by-products.', 'Các hoạt động toàn cầu của chúng tôi bắt nguồn từ kiến thức và kinh nghiệm sâu rộng trong việc cải thiện chuỗi cung ứng, quản lý rủi ro và phân phối tập trung vào khách hàng để tạo ra một môi trường có giá trị và có lợi cho các nhà cung cấp và khách hàng của chúng tôi.', 'Our global operations stem from our extensive knowledge and experience in supply chain improvement, risk management, and client-focused distribution to create a valuable and profitable environment for our suppliers and customers.', 'Được thành lập vào năm 2007 với 15 năm hoạt động và thành tích tài chính. Chúng tôi đã giao hơn 500 triệu lít Dầu Đã Qua Sử Dụng (UCO) kể từ năm 2017.|Công ty dẫn đầu thị trường tại các thị trường xuất khẩu chính ở Châu Á.', 'Founded in 2007 with 15 years of operational and financial track record. We have delivered more than 500 million litres of UCO since 2017. |The market leader in key export markets in Asia.', 'https://apeironbioenergy.vn/images/posts/_about/2155d467c6451c1b4554.jpg', 'Tại sao phải tái chế dầu ăn đã qua sử dụng?', 'Why Recycle Used Cooking Oil?', '<p>Bạn có biết việc chuyển đổi từ dầu diesel xăng sang dầu diesel tái tạo làm bằng UCO dẫn đến lượng khí thải nhà kính thấp hơn 83% không? Bằng cách tái chế UCO, bạn đang góp phần tiết kiệm khí nhà kính và giúp bảo vệ trái đất của chúng ta thông qua nỗ lực phát triển bền vững của bạn.\r\n</p><p>\r\nViệc xử lý UCO không đúng cách làm tắc nghẽn nghiêm trọng hệ thống nước thải. Chỉ riêng San Francisco đã chi 3,5 triệu đô la hàng năm để thông cống rãnh chứa đầy chất béo, dầu và mỡ!</p>', '<p>Did you know switching from petroleum diesel to renewable diesel made of UCO results in more than 83% lower greenhouse gas emissions? By recycling UCO, you are contributing towards greenhouse gas savings and helping to preserve our earth through your sustainability effort.</p>\r\n<p>\r\nThe incorrect disposal of UCO severely clogs the sewage system. San Francisco alone spends $3.5 million annually to unclog sewers filled with fats, oils, and grease!</p>', 'https://apeironbioenergy.vn/images/posts/_about/about.jpg', 'Quy trình xử lý', 'Process', 'Lập kế hoạch chi tiết từ các nhóm quốc gia của chúng tôi với cộng đồng địa phương\r\n |Thu thập và giao cho các cơ sở thu gom và xử lý của chúng tôi\r\n  |Để yên, lọc và đun nóng để tách nước, cặn và dầu\r\n  |Cung cấp cho bể chứa trung tâm và xử lý nhiệt nhiều hơn\r\n  |Xuất khẩu đến các nhà máy lọc dầu diesel sinh học thông qua các tàu hàng rời', ' Detailed planning from our country teams with the local community\r\n |Collect and deliver to our collection and processing facilities\r\n |Rest, filter, and heat to separate water, residue, and oil\r\n |Deliver to central storage tanks and more heat treatment\r\n |Export to biodiesel refineries through bulk vessels', 'Liên hệ', 'Contact us', 'Xin vui lòng để lại thông tin bạn cần liên hệ', 'Feel Free To Contact Us', 'fa fa-map-marker|Địa chỉ|Kho Bình Dương: 18/14 Hai Bà Trưng Nối Dài, Khu Phố Tây B, Phường Đông Hòa, TP. Dĩ An, tỉnh Bình Dương||fa fa-envelope|Email|hung.nguyen@apeironbioenergy.com||fa fa-phone|Gọi cho chúng tôi|+84977240268', 'fa fa-map-marker|Our Office|Kho Bình Dương: 18/14 Hai Bà Trưng Nối Dài, Khu Phố Tây B, Phường Đông Hòa, TP. Dĩ An, tỉnh Bình Dương||fa fa-envelope|Email Us|hung.nguyen@apeironbioenergy.com||fa fa-envelope|fa fa-phone|+84977240268', 0, '<h3 class=\"text-white mb-3\">Giờ mở cửa</h3>\r\n<div class=\"d-flex justify-content-between text-white mb-3\">\r\n<h6 class=\"text-white mb-0\">Thứ 2 - Thứ 6</h6>\r\n<p class=\"mb-0\">8:00am - 9:00pm</p>\r\n</div>\r\n<div class=\"d-flex justify-content-between text-white mb-3\">\r\n<h6 class=\"text-white mb-0\">Thứ 7</h6>\r\n<p class=\"mb-0\">8:00am - 7:00pm</p>\r\n</div>\r\n<div class=\"d-flex justify-content-between text-white mb-3\">\r\n<h6 class=\"text-white mb-0\">Chủ nhật</h6>\r\n<p class=\"mb-0\">8:00am - 5:00pm</p>\r\n</div>\r\n<a class=\"btn btn-light\" href=\"/contact\">Đặt lịch hẹn</a>', '<h3 class=\"text-white mb-3\">Li&ecirc;n hệ ngay</h3>\r\n<p class=\"text-white\">Bạn c&oacute; thể gọi đến số hotline của ch&uacute;ng t&ocirc;i để y&ecirc;u cầu dịch vụ hoặc cần li&ecirc;n hệ c&ocirc;ng việc</p>\r\n<h2 class=\"text-white mb-0\">+84977240268</h2>', '<h3 class=\"text-white mb-3\">Opening Hours</h3>\r\n<div class=\"d-flex justify-content-between text-white mb-3\">\r\n<h6 class=\"text-white mb-0\">Mon - Fri</h6>\r\n<p class=\"mb-0\">8:00am - 9:00pm</p>\r\n</div>\r\n<div class=\"d-flex justify-content-between text-white mb-3\">\r\n<h6 class=\"text-white mb-0\">Saturday</h6>\r\n<p class=\"mb-0\">8:00am - 7:00pm</p>\r\n</div>\r\n<div class=\"d-flex justify-content-between text-white mb-3\">\r\n<h6 class=\"text-white mb-0\">Sunday</h6>\r\n<p class=\"mb-0\">8:00am - 5:00pm</p>\r\n</div>\r\n<a class=\"btn btn-light\" href=\"/site/appointment\">Appointment</a>', '<h3 class=\"text-white mb-3\">Make Appointment</h3>\r\n<p class=\"text-white\">You can call our hotline to request service or need to contact work</p>\r\n<h2 class=\"text-white mb-0\">+84977240268</h2>', 'https://apeironbioenergy.vn/images/posts/_default/1476.gif', 'https://apeironbioenergy.vn/images/posts/_default/1476.gif', 'Apeiron Bioenergy Vietnam', 'Apeiron Bioenergy is a leading integrated global player in the entire chain of bioenergy products from feedstock to the end and by-products.', 4, 5, 10, 5, 0, 'Giá Trị', 'Sustainability', '<h1>T&iacute;nh bền vững cốt l&otilde;i của ch&uacute;ng t&ocirc;i</h1>\r\n<p>Ch&uacute;ng t&ocirc;i thu gom r&aacute;c thải với sứ mệnh bảo vệ m&ocirc;i trường, n&acirc;ng cao nhận thức v&agrave; đại diện cho lợi &iacute;ch của ng&agrave;nh năng lượng sinh học.</p>\r\n<p>Ch&uacute;ng t&ocirc;i thực hiện c&aacute;c ti&ecirc;u ch&iacute; bền vững về x&atilde; hội v&agrave; sinh th&aacute;i nghi&ecirc;m ngặt trong quy tr&igrave;nh quản l&yacute; chuỗi cung ứng của m&igrave;nh. Qu&aacute; tr&igrave;nh n&agrave;y được kiểm tra thường xuy&ecirc;n v&agrave; c&aacute;c sản phẩm của ch&uacute;ng t&ocirc;i được chứng nhận với c&aacute;c ti&ecirc;u chuẩn bền vững như Chứng nhận Carbon &amp; Bền vững Quốc tế (ISCC) dầu mỏ.</p>\r\n<p>Th&ocirc;ng qua sự hợp t&aacute;c với c&aacute;c hộ gia đ&igrave;nh, nh&agrave; h&agrave;ng, kh&aacute;ch sạn, nh&agrave; sản xuất thực phẩm địa phương, ch&uacute;ng t&ocirc;i n&acirc;ng cao nhận thức v&agrave; khuyến kh&iacute;ch việc xử l&yacute; r&aacute;c thải đ&uacute;ng c&aacute;ch.</p>\r\n<p>Đồng thời, ch&uacute;ng t&ocirc;i tạo cơ hội việc l&agrave;m cho c&aacute;c nền kinh tế địa phương th&ocirc;ng qua c&aacute;c hoạt động t&aacute;i chế.</p>\r\n<h1>T&aacute;c động của ch&uacute;ng t&ocirc;i về số lượng</h1>\r\n<p><img src=\"/images/posts/20230302-100247-rDeb/image1.jpg\" alt=\"\" width=\"100%\" /></p>\r\n<p><img src=\"/images/posts/20230302-100247-rDeb/image2.jpg\" alt=\"\" width=\"100%\" /></p>', '<h1 class=\"envionmnet-ttle\" data-w-id=\"23139613-11a9-b459-83dd-3d86c5ccdc8e\">Sustainability at Our Core<img class=\"environment-icon\" src=\"https://assets.website-files.com/622ecbb1fc363c1753ddeb5f/6230696327bb278eec2df55b_noun-green-city-1085044.svg\" alt=\"\" /></h1>\r\n<div class=\"enironmnet-content\">\r\n<div class=\"environmnet-text\">We collect wastes with the mission of protecting the environment, creating awareness, and representing the interests of the bioenergy industry.</div>\r\n</div>\r\n<div class=\"enironmnet-content\"><br />\r\n<div class=\"environmnet-text\">We implement rigorous ecological and social sustainability criteria in our supply chain management process. This process is audited regularly and our products are certified with sustainability standards such as International Sustainability &amp; Carbon Certification (ISCC) .</div>\r\n</div>\r\n<div class=\"enironmnet-content\"><br />\r\n<div class=\"environmnet-text\">Our business directly reduces the social costs of clogged sewage and reduced efficiency of wastewater treatment systems as a result of illegal disposal of used cooking oil.<br /><br />Through collaborations with local households, restaurants, hotels, food manufacturers, we create awareness and encourage the proper disposal of waste. At the same time, we create job opportunities for local economies through recycling activities.</div>\r\n<div class=\"environmnet-text\">&nbsp;</div>\r\n<div class=\"environmnet-text\">\r\n<h1 class=\"impact-title\" data-w-id=\"68f7fa92-83b1-c141-b7c7-897ff11d9b75\">Our Impact in Numbers</h1>\r\n<p><img src=\"/images/posts/20230302-095720-NO9t/image1.jpg\" alt=\"\" width=\"100%\" height=\"\" /></p>\r\n<p><img src=\"/images/posts/20230302-095720-NO9t/image2.jpg\" alt=\"\" width=\"100%\" height=\"\" /></p>\r\n</div>\r\n</div>', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `socials`
--

DROP TABLE IF EXISTS `socials`;
CREATE TABLE IF NOT EXISTS `socials` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `icon` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `link` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `priority` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `socials`
--

INSERT INTO `socials` (`id`, `name`, `icon`, `link`, `priority`) VALUES
(1, 'Facebook', '<span class=\"icon-facebook\"></span>', 'facebook.com', 2),
(2, 'Twitter', '<span class=\"icon-twitter\"></span>', 'twitter.com', 1),
(3, 'Instagram', '<span class=\"icon-instagram\"></span>', 'instagram.com', 1),
(4, 'Youtube', '<span class=\"icon-youtube-play\"></span>', 'youtube.com', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tag_list`
--

DROP TABLE IF EXISTS `tag_list`;
CREATE TABLE IF NOT EXISTS `tag_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  `seo_title` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_description` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tag_list`
--

INSERT INTO `tag_list` (`id`, `name`, `slug`, `date_created`, `user_created`, `seo_title`, `seo_description`) VALUES
(1, 'tag 1', 'tag-1', '2024-01-16 16:25:52', NULL, '', ''),
(2, 'tag 2', 'tag-2', '2024-01-16 16:25:52', NULL, NULL, NULL),
(3, 'tag 3', 'tag-3', '2024-01-16 16:32:55', 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `auth_key` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `confirmation_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `superadmin` smallint(1) DEFAULT '0',
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  `registration_ip` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bind_to_ip` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email_confirmed` smallint(1) NOT NULL DEFAULT '0',
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `id_phong` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `auth_key`, `password_hash`, `confirmation_token`, `status`, `superadmin`, `created_at`, `updated_at`, `registration_ip`, `bind_to_ip`, `email`, `email_confirmed`, `name`, `phone`, `address`, `id_phong`) VALUES
(1, 'superadmin@gmail.com', 'kz2px152FAWlkHbkZoCiXgBAd-S8SSjF', '$2y$13$DSISRUJSkr4CPeb3Ciwl1u3ubaGF50gXzzgTaDmpi5ph2Hie8JL9q', NULL, 1, 1, 1426062188, 1586049758, NULL, '', 'superadmin@gmail.com', 1, 'Mr. Admin 1', '374711908', 'Càng Long - Trà Vinh 1', 1);

-- --------------------------------------------------------

--
-- Table structure for table `user_visit_log`
--

DROP TABLE IF EXISTS `user_visit_log`;
CREATE TABLE IF NOT EXISTS `user_visit_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ip` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `language` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `user_agent` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `visit_time` int(11) NOT NULL,
  `browser` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `os` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=254 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `user_visit_log`
--

INSERT INTO `user_visit_log` (`id`, `token`, `ip`, `language`, `user_agent`, `user_id`, `visit_time`, `browser`, `os`) VALUES
(1, '594b942a08db7', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.104 Safari/537.36', 1, 1498125354, 'Chrome', 'Windows'),
(2, '594e6c6038079', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.104 Safari/537.36', 1, 1498311776, 'Chrome', 'Windows'),
(3, '594f4139aedb5', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.104 Safari/537.36', 1, 1498366265, 'Chrome', 'Windows'),
(4, '595ef7d44d1b0', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 1, 1499396052, 'Chrome', 'Windows'),
(5, '59e8a6d8a9558', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 1, 1508419288, 'Chrome', 'Windows'),
(6, '59ee962cb327d', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 1, 1508808236, 'Chrome', 'Windows'),
(7, '59ef5ebdeec13', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 1, 1508859581, 'Chrome', 'Windows'),
(8, '59ef6a5ad7e55', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 1, 1508862554, 'Chrome', 'Windows'),
(9, '59ef70a2e9811', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 1, 1508864162, 'Chrome', 'Windows'),
(10, '59f0b2e7171a8', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 1, 1508946663, 'Chrome', 'Windows'),
(11, '59f0cd9d161a9', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 1, 1508953501, 'Chrome', 'Windows'),
(12, '59f1304f26745', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 1, 1508978767, 'Chrome', 'Windows'),
(13, '59f1456cbea96', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 1, 1508984172, 'Chrome', 'Windows'),
(14, '59f1807420d18', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 1, 1508999284, 'Chrome', 'Windows'),
(15, '59f29d6be7ea5', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 1, 1509072235, 'Chrome', 'Windows'),
(16, '59f2e74688480', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 1, 1509091142, 'Chrome', 'Windows'),
(17, '59f3d7d1bcc8f', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 1, 1509152721, 'Chrome', 'Windows'),
(18, '59f688a11dd11', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 1, 1509329057, 'Chrome', 'Windows'),
(19, '59f6c6b702579', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 1, 1509344951, 'Chrome', 'Windows'),
(20, '59f747ceb4e37', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 1, 1509377998, 'Chrome', 'Windows'),
(21, '59f992dfa3650', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 1, 1509528287, 'Chrome', 'Windows'),
(22, '59f9e7bbac6f9', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 1, 1509550011, 'Chrome', 'Windows'),
(23, '59fff730e5ab3', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 1, 1509947184, 'Chrome', 'Windows'),
(24, '5a005c828502a', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 1, 1509973122, 'Chrome', 'Windows'),
(25, '5a00833f42ef8', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 1, 1509983039, 'Chrome', 'Windows'),
(26, '5a008bd985854', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 1, 1509985241, 'Chrome', 'Windows'),
(27, '5a032315d55e7', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 1, 1510155029, 'Chrome', 'Windows'),
(28, '5a09a9c638959', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 1, 1510582726, 'Chrome', 'Windows'),
(29, '5a0bcc8d46ae1', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 1, 1510722701, 'Chrome', 'Windows'),
(30, '5a0c507c1bbc0', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 1, 1510756476, 'Chrome', 'Windows'),
(31, '5a158ee83c3a5', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36', 1, 1511362280, 'Chrome', 'Windows'),
(32, '5a16e76aac9a0', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36', 1, 1511450474, 'Chrome', 'Windows'),
(33, '5a1c03e4e7758', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36', 1, 1511785444, 'Chrome', 'Windows'),
(34, '5a1c2a002fa8d', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36', 1, 1511795200, 'Chrome', 'Windows'),
(35, '5a1d8a8b23e08', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36', 1, 1511885451, 'Chrome', 'Windows'),
(36, '5a202b327efa1', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36', 1, 1512057650, 'Chrome', 'Windows'),
(37, '5a24d16ba2ee7', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36', 1, 1512362347, 'Chrome', 'Windows'),
(38, '5a256932f0cc3', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36', 1, 1512401202, 'Chrome', 'Windows'),
(39, '5a26c795b5a20', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36', 1, 1512490901, 'Chrome', 'Windows'),
(40, '5a2ab2d0d270e', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36', 1, 1512747728, 'Chrome', 'Windows'),
(41, '5a2e1341e8e0e', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36', 1, 1512969025, 'Chrome', 'Windows'),
(42, '5a329a097ad3f', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.84 Safari/537.36', 1, 1513265673, 'Chrome', 'Windows'),
(43, '5a33e86702cf4', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.84 Safari/537.36', 1, 1513351271, 'Chrome', 'Windows'),
(44, '5b8566d214a65', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', 1, 1535469266, 'Chrome', 'Windows'),
(45, '5b878bb8d24fd', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', 1, 1535609784, 'Chrome', 'Windows'),
(46, '5b880eecbba11', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', 1, 1535643372, 'Chrome', 'Windows'),
(47, '5b8c87273a4fc', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', 1, 1535936295, 'Chrome', 'Windows'),
(48, '5b8d23079177c', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', 1, 1535976199, 'Chrome', 'Windows'),
(49, '5b8ddf31af79a', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', 1, 1536024369, 'Chrome', 'Windows'),
(50, '5b8e819351601', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', 1, 1536065939, 'Chrome', 'Windows'),
(51, '5b8e9d9d98f1c', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', 1, 1536073117, 'Chrome', 'Windows'),
(52, '5b8ea8323c5b1', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', 1, 1536075826, 'Chrome', 'Windows'),
(53, '5b8ea9e478538', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', 1, 1536076260, 'Chrome', 'Windows'),
(54, '5b8f277b1677c', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', 1, 1536108411, 'Chrome', 'Windows'),
(55, '5b8f76b89e150', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', 1, 1536128696, 'Chrome', 'Windows'),
(56, '5b908f32ac6d8', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', 1, 1536200498, 'Chrome', 'Windows'),
(57, '5b9a80b80c904', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', NULL, 1536852152, 'Chrome', 'Windows'),
(58, '5b9a812bb36a9', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', 1, 1536852267, 'Chrome', 'Windows'),
(59, '5b9a860f21927', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', NULL, 1536853519, 'Chrome', 'Windows'),
(60, '5b9a876886dcd', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', NULL, 1536853864, 'Chrome', 'Windows'),
(61, '5b9a881b4ba36', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', NULL, 1536854043, 'Chrome', 'Windows'),
(62, '5b9a89a9e4cc1', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', NULL, 1536854441, 'Chrome', 'Windows'),
(63, '5b9bbc7979e36', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', 1, 1536932985, 'Chrome', 'Windows'),
(64, '5b9e6fa2dcd51', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', 1, 1537109922, 'Chrome', 'Windows'),
(65, '5ba1eeb6c9155', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', 1, 1537339062, 'Chrome', 'Windows'),
(66, '5ba7187e1e6ea', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.81 Safari/537.36 Avast/69.0.792.81', 1, 1537677438, 'Chrome', 'Windows'),
(67, '5ba7195ab7712', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36', 1, 1537677658, 'Chrome', 'Windows'),
(68, '5ba8816455e8d', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36', 1, 1537769828, 'Chrome', 'Windows'),
(69, '5baa542ec53a9', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36', 1, 1537889326, 'Chrome', 'Windows'),
(70, '5baa55d7d6912', '::1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:56.0) Gecko/20100101 Firefox/56.0', 1, 1537889751, 'Firefox', 'Windows'),
(71, '5bac244e659d1', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36', 1, 1538008142, 'Chrome', 'Windows'),
(72, '5bb1734b8dffa', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36', 1, 1538356043, 'Chrome', 'Windows'),
(73, '5bb433d544aad', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36', 1, 1538536405, 'Chrome', 'Windows'),
(74, '5c2037ee33982', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36', 1, 1545615342, 'Chrome', 'Windows'),
(75, '5ca93b363c1d5', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.86 Safari/537.36', 1, 1554594614, 'Chrome', 'Windows'),
(76, '5cb881f5a13b5', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 1, 1555595765, 'Chrome', 'Windows'),
(77, '5cb8a07a1a58a', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 1, 1555603578, 'Chrome', 'Windows'),
(78, '5cb8a3345894c', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', NULL, 1555604276, 'Chrome', 'Windows'),
(79, '5cb8a46ceb412', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', NULL, 1555604588, 'Chrome', 'Windows'),
(80, '5cb8a4db8e4e6', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', NULL, 1555604699, 'Chrome', 'Windows'),
(81, '5cb8a81ce9027', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', NULL, 1555605532, 'Chrome', 'Windows'),
(82, '5cb8ad0e4d571', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', NULL, 1555606798, 'Chrome', 'Windows'),
(83, '5cb8ad3a61129', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', NULL, 1555606842, 'Chrome', 'Windows'),
(84, '5cb9245bd697b', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', NULL, 1555637339, 'Chrome', 'Windows'),
(85, '5cb94239a8a3c', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', NULL, 1555644985, 'Chrome', 'Windows'),
(86, '5cb9431be7c4e', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', NULL, 1555645211, 'Chrome', 'Windows'),
(87, '5cb943c69bec8', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 1, 1555645382, 'Chrome', 'Windows'),
(88, '5cb9f703675a5', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 1, 1555691267, 'Chrome', 'Windows'),
(89, '5cba88e7ab1b0', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 1, 1555728615, 'Chrome', 'Windows'),
(90, '5cbb34767942f', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 1, 1555772534, 'Chrome', 'Windows'),
(91, '5cc11ae1685bb', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 1, 1556159201, 'Chrome', 'Windows'),
(92, '5cc2b15586208', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 1, 1556263253, 'Chrome', 'Windows'),
(93, '5cc3f0f405d84', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 1, 1556345076, 'Chrome', 'Windows'),
(94, '5cc84741d0fbb', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 1, 1556629313, 'Chrome', 'Windows'),
(95, '5d4974633a124', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', 1, 1565095011, 'Chrome', 'Windows'),
(96, '5d4e27b421051', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36', 1, 1565403060, 'Chrome', 'Windows'),
(97, '5d50b845dd0c4', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36', 1, 1565571141, 'Chrome', 'Windows'),
(98, '5d538429662db', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36', 1, 1565754409, 'Chrome', 'Windows'),
(99, '5d53854e94bdc', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36', 1, 1565754702, 'Chrome', 'Windows'),
(100, '5d5388a9aed8b', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36', 1, 1565755561, 'Chrome', 'Windows'),
(101, '5d53abcf46651', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36', 1, 1565764559, 'Chrome', 'Windows'),
(102, '5d779315820f5', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36', 1, 1568117525, 'Chrome', 'Windows'),
(103, '5d78a4f3c95dd', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36', 1, 1568187635, 'Chrome', 'Windows'),
(104, '5d95b078d3259', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36', 1, 1570091128, 'Chrome', 'Windows'),
(105, '5d96268fc2554', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36', 1, 1570121359, 'Chrome', 'Windows'),
(106, '5d96269ed67ee', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36', NULL, 1570121374, 'Chrome', 'Windows'),
(107, '5d96f34b0fc1e', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36', 1, 1570173771, 'Chrome', 'Windows'),
(108, '5d989cad3a601', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36', 1, 1570282669, 'Chrome', 'Windows'),
(109, '5da82e7283d94', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.120 Safari/537.36', 1, 1571303026, 'Chrome', 'Windows'),
(110, '5da97c8d06f4e', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.120 Safari/537.36', 1, 1571388557, 'Chrome', 'Windows'),
(111, '5dafaddb87cd8', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.120 Safari/537.36', 1, 1571794395, 'Chrome', 'Windows'),
(112, '5dbe1b954efdc', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.120 Safari/537.36', 1, 1572739989, 'Chrome', 'Windows'),
(113, '5e4debc821c02', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.116 Safari/537.36', 1, 1582164936, 'Chrome', 'Windows'),
(114, '5e549263d8fb4', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.116 Safari/537.36', 1, 1582600803, 'Chrome', 'Windows'),
(115, '5e5dad753e106', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.122 Safari/537.36', 1, 1583197557, 'Chrome', 'Windows'),
(116, '5e5f53a1b905f', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.122 Safari/537.36', 1, 1583305633, 'Chrome', 'Windows'),
(117, '5e60722a6bedf', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.122 Safari/537.36', 1, 1583378986, 'Chrome', 'Windows'),
(118, '5e6116f3a4287', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.122 Safari/537.36', 1, 1583421171, 'Chrome', 'Windows'),
(119, '5e61f1a59e18a', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', 1, 1583477157, 'Chrome', 'Windows'),
(120, '5e6607738f7eb', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', 1, 1583744883, 'Chrome', 'Windows'),
(121, '5e6659e348e5d', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', 1, 1583765987, 'Chrome', 'Windows'),
(122, '5e674a99468e5', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', 1, 1583827609, 'Chrome', 'Windows'),
(123, '5e686bcb64f52', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', 1, 1583901643, 'Chrome', 'Windows'),
(124, '5e698721e44b9', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', 1, 1583974177, 'Chrome', 'Windows'),
(125, '5e69a03b878af', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', 1, 1583980603, 'Chrome', 'Windows'),
(126, '5e6ad745790df', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', 1, 1584060229, 'Chrome', 'Windows'),
(127, '5e6afa6675f2c', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', 1, 1584069222, 'Chrome', 'Windows'),
(128, '5e6ecce078976', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', 1, 1584319712, 'Chrome', 'Windows'),
(129, '5e71c528c782c', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', 1, 1584514344, 'Chrome', 'Windows'),
(130, '5e71c56635718', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', NULL, 1584514406, 'Chrome', 'Windows'),
(131, '5e71c820cbd73', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', 1, 1584515104, 'Chrome', 'Windows'),
(132, '5e71d255f30c1', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', NULL, 1584517717, 'Chrome', 'Windows'),
(133, '5e72c6a32ed18', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', 1, 1584580259, 'Chrome', 'Windows'),
(134, '5e742c60879d0', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', 1, 1584671840, 'Chrome', 'Windows'),
(135, '5e78118d82a5c', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', 1, 1584927117, 'Chrome', 'Windows'),
(136, '5e78667e3345d', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', 1, 1584948862, 'Chrome', 'Windows'),
(137, '5e795d15dc80c', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', 1, 1585011989, 'Chrome', 'Windows'),
(138, '5e7d6b5f90456', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', 1, 1585277791, 'Chrome', 'Windows'),
(139, '5e81a6f53943d', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', 1, 1585555189, 'Chrome', 'Windows'),
(140, '5e829a6cdb25e', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', 1, 1585617516, 'Chrome', 'Windows'),
(141, '5e8448e4e9c92', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', 1, 1585727716, 'Chrome', 'Windows'),
(142, '5e848206686ae', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', 1, 1585742342, 'Chrome', 'Windows'),
(143, '5e86b5b0e7d81', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', 1, 1585886640, 'Chrome', 'Windows'),
(144, '5e86f3cc5e02c', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.162 Safari/537.36', 1, 1585902540, 'Chrome', 'Windows'),
(145, '5e87060000c41', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.162 Safari/537.36', 1, 1585907200, 'Chrome', 'Windows'),
(146, '5e88323f677a6', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.162 Safari/537.36', 1, 1585984063, 'Chrome', 'Windows'),
(147, '5e8836c203a18', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.162 Safari/537.36', 1, 1585985218, 'Chrome', 'Windows'),
(148, '5e884af3b7e61', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', 1, 1585990387, 'Chrome', 'Windows'),
(149, '5e88600ddd2db', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', 1, 1585995789, 'Chrome', 'Windows'),
(150, '5e892beb48615', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', 1, 1586047979, 'Chrome', 'Windows'),
(151, '5e8932ae84461', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', 1, 1586049710, 'Chrome', 'Windows'),
(152, '5e89331dd420c', '10.202.27.243', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', 1, 1586049821, 'Chrome', 'Windows'),
(153, '5e8939720c509', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', 1, 1586051442, 'Chrome', 'Windows'),
(154, '5e89c3f053845', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', NULL, 1586086896, 'Chrome', 'Windows'),
(155, '5e8d3f40373d6', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', 1, 1586315072, 'Chrome', 'Windows'),
(156, '5e8d3f6a1189d', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', NULL, 1586315114, 'Chrome', 'Windows'),
(157, '5e9080ca1b2ca', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', 1, 1586528458, 'Chrome', 'Windows'),
(158, '5e9256944d3d3', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', 1, 1586648724, 'Chrome', 'Windows'),
(159, '5e957a1cdb486', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', 1, 1586854428, 'Chrome', 'Windows'),
(160, '5e97bffb6e420', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', 1, 1587003387, 'Chrome', 'Windows'),
(161, '5eba4bcdba14c', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36', 1, 1589267405, 'Chrome', 'Windows'),
(162, '5edd850fb15a0', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36', 1, 1591575823, 'Chrome', 'Windows'),
(163, '5edd868884ab7', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36', NULL, 1591576200, 'Chrome', 'Windows'),
(164, '5edda481d9e66', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36', NULL, 1591583873, 'Chrome', 'Windows'),
(165, '5edee38066441', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36', 1, 1591665536, 'Chrome', 'Windows'),
(166, '5edee3c6c76b1', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36', NULL, 1591665606, 'Chrome', 'Windows'),
(167, '5edee506e4fec', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36', NULL, 1591665926, 'Chrome', 'Windows'),
(168, '5ef4c54e40700', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.116 Safari/537.36', 1, 1593099598, 'Chrome', 'Windows'),
(169, '5ef550a2613b5', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.116 Safari/537.36', 1, 1593135266, 'Chrome', 'Windows'),
(170, '5f067152e1d34', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.116 Safari/537.36', 1, 1594257746, 'Chrome', 'Windows'),
(171, '5f06719fc5bb6', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.116 Safari/537.36', NULL, 1594257823, 'Chrome', 'Windows'),
(172, '5fa257308e037', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.183 Safari/537.36', 1, 1604474672, 'Chrome', 'Windows'),
(173, '5fa4b80680060', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.183 Safari/537.36', 1, 1604630534, 'Chrome', 'Windows'),
(174, '60372d29b9962', '127.0.0.1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.182 Safari/537.36', 1, 1614228777, 'Chrome', 'Windows'),
(175, '60372d6f5b7d8', '127.0.0.1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.182 Safari/537.36', NULL, 1614228847, 'Chrome', 'Windows'),
(176, '6046e9137ab3f', '127.0.0.1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.190 Safari/537.36', 1, 1615259923, 'Chrome', 'Windows'),
(177, '604819f5303f1', '127.0.0.1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.190 Safari/537.36', 1, 1615337973, 'Chrome', 'Windows'),
(178, '6049d8e5dd6b4', '127.0.0.1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.190 Safari/537.36', 1, 1615452389, 'Chrome', 'Windows'),
(179, '6049dbfee39a9', '127.0.0.1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.190 Safari/537.36', NULL, 1615453182, 'Chrome', 'Windows'),
(180, '604ac159e6b22', '127.0.0.1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.190 Safari/537.36', 1, 1615511897, 'Chrome', 'Windows'),
(181, '60b9e1083005c', '127.0.0.1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.77 Safari/537.36', 1, 1622794504, 'Chrome', 'Windows'),
(182, '60bae34d258f6', '127.0.0.1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.77 Safari/537.36', 1, 1622860621, 'Chrome', 'Windows'),
(183, '60bae52d0535a', '127.0.0.1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.77 Safari/537.36', 1, 1622861101, 'Chrome', 'Windows'),
(184, '60bd8da9800d5', '127.0.0.1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.77 Safari/537.36', 1, 1623035305, 'Chrome', 'Windows'),
(185, '60eba51ba1bb3', '127.0.0.1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36', 1, 1626055963, 'Chrome', 'Windows'),
(186, '60eba6ba36295', '127.0.0.1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36', NULL, 1626056378, 'Chrome', 'Windows'),
(187, '60eba751bbf8b', '127.0.0.1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36', NULL, 1626056529, 'Chrome', 'Windows'),
(188, '60eba7aa864ac', '127.0.0.1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36', NULL, 1626056618, 'Chrome', 'Windows'),
(189, '60eba8330509e', '127.0.0.1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36', NULL, 1626056755, 'Chrome', 'Windows'),
(190, '60eba8ccdb5ac', '127.0.0.1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36', NULL, 1626056908, 'Chrome', 'Windows'),
(191, '6194ce72de6c5', '127.0.0.1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.69 Safari/537.36', 1, 1637142130, 'Chrome', 'Windows'),
(192, '619746aa90c09', '127.0.0.1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.69 Safari/537.36', 1, 1637303978, 'Chrome', 'Windows'),
(193, '619751d50efb4', '127.0.0.1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.69 Safari/537.36', 1, 1637306837, 'Chrome', 'Windows'),
(194, '619ae916a5efa', '127.0.0.1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.45 Safari/537.36', 1, 1637542166, 'Chrome', 'Windows'),
(195, '619d151c20277', '127.0.0.1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.45 Safari/537.36', 1, 1637684508, 'Chrome', 'Windows'),
(196, '619e714974085', '127.0.0.1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.45 Safari/537.36', 1, 1637773641, 'Chrome', 'Windows'),
(197, '619f3511248ca', '127.0.0.1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.45 Safari/537.36', 1, 1637823761, 'Chrome', 'Windows'),
(198, '61a03438d06ce', '127.0.0.1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.45 Safari/537.36', 1, 1637889080, 'Chrome', 'Windows'),
(199, '61e8db9c551ae', '127.0.0.1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/97.0.4692.71 Safari/537.36', 1, 1642650524, 'Chrome', 'Windows'),
(200, '62067ec846026', '127.0.0.1', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.82 Safari/537.36', 1, 1644592840, 'Chrome', 'Windows'),
(201, '6320160e8ed28', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36', 1, 1663047182, 'Chrome', 'Windows'),
(202, '6326dc416dd21', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36', 1, 1663491137, 'Chrome', 'Windows'),
(203, '632eb85c535fa', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36', 1, 1664006236, 'Chrome', 'Windows'),
(204, '632fe04cd5313', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36', 1, 1664081996, 'Chrome', 'Windows'),
(205, '63331bf466694', '113.182.184.9', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36', NULL, 1664293876, 'Chrome', 'Windows'),
(206, '63331cd3edcd6', '113.182.184.9', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36', NULL, 1664294099, 'Chrome', 'Windows'),
(207, '63342574185ac', '113.182.184.9', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36', 1, 1664361844, 'Chrome', 'Windows'),
(208, '63382ff1e92e5', '14.191.61.205', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36', 1, 1664626673, 'Chrome', 'Windows'),
(209, '633cefca2fdcc', '123.23.13.149', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36', 1, 1664937930, 'Chrome', 'Windows'),
(210, '633fd7b3d7141', '118.68.56.13', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36', 1, 1665128371, 'Chrome', 'Windows'),
(211, '635b6b16f0db1', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36', 1, 1666935574, 'Chrome', 'Windows'),
(212, '63a06823b2435', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36', 1, 1671456803, 'Chrome', 'Windows'),
(213, '63ee404a622f1', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36', 1, 1676558410, 'Chrome', 'Windows'),
(214, '63ef01ab72671', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36', 1, 1676607915, 'Chrome', 'Windows'),
(215, '63f1c3c13350a', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36', 1, 1676788673, 'Chrome', 'Windows'),
(216, '63fdf6a9c8ce8', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36', 1, 1677588137, 'Chrome', 'Windows'),
(217, '63fe0639a9d95', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36', 1, 1677592121, 'Chrome', 'Windows'),
(218, '63fe0fc3cb2e3', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36', 1, 1677594563, 'Chrome', 'Windows'),
(219, '63fe8683cb897', '127.0.0.1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36', 1, 1677624963, 'Chrome', 'Windows'),
(220, '64002a2aa8f01', '2001:ee0:56e8:8', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36', 1, 1677732394, 'Chrome', 'Windows'),
(221, '64003618c41db', '2001:ee0:56e8:8', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36', 1, 1677735448, 'Chrome', 'Windows'),
(222, '64003f4ad1878', '171.247.108.233', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36 Edg/110.0.1587.57', 1, 1677737802, 'Chrome', 'Windows'),
(223, '64101d5c9879f', '14.224.160.12', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36 Edg/110.0.1587.69', 1, 1678777692, 'Chrome', 'Windows'),
(224, '6412b1078c242', '1.52.109.14', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/111.0.0.0 Safari/537.36', 1, 1678946567, 'Chrome', 'Windows'),
(225, '6413d22105926', '42.115.229.57', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/111.0.0.0 Safari/537.36', 1, 1679020577, 'Chrome', 'Windows'),
(226, '642fbff3254ee', '14.224.160.12', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/111.0.0.0 Safari/537.36 Edg/111.0.1661.62', 1, 1680850931, 'Chrome', 'Windows'),
(227, '642fc1e3791b1', '14.224.160.12', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/111.0.0.0 Safari/537.36 Edg/111.0.1661.62', 1, 1680851427, 'Chrome', 'Windows'),
(228, '642fd39ece936', '113.188.229.40', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/111.0.0.0 Safari/537.36', 1, 1680855966, 'Chrome', 'Windows'),
(229, '64322f2ef2155', '27.3.193.217', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/111.0.0.0 Safari/537.36', 1, 1681010478, 'Chrome', 'Windows'),
(230, '64521421f2784', '113.183.205.19', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36', 1, 1683100705, 'Chrome', 'Windows'),
(231, '6489b99276bfe', '222.254.222.131', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36', 1, 1686747538, 'Chrome', 'Windows'),
(232, '648fbe8196ce8', '2402:800:63e5:b', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36', 1, 1687142017, 'Chrome', 'Windows'),
(233, '64b644ea0dc65', '14.224.160.12', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36', 1, 1689666794, 'Chrome', 'Windows'),
(234, '64b64661f3649', '14.224.160.12', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36', 1, 1689667169, 'Chrome', 'Windows'),
(235, '64b8a6eee72b4', '2402:800:63e5:f', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36', 1, 1689822958, 'Chrome', 'Windows'),
(236, '64b8a87199516', '113.177.113.64', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36 Edg/114.0.1823.82', 1, 1689823345, 'Chrome', 'Windows'),
(237, '64bb4adf327cf', '14.224.160.12', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36 Edg/114.0.1823.82', 1, 1689995999, 'Chrome', 'Windows'),
(238, '64bb51934194d', '2402:800:63e5:f', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36', 1, 1689997715, 'Chrome', 'Windows'),
(239, '64c8ad0b4788c', '14.224.160.12', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36 Edg/115.0.1901.188', 1, 1690873099, 'Chrome', 'Windows'),
(240, '64cb67a9bddf2', '2402:800:63e5:f', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36', 1, 1691051945, 'Chrome', 'Windows'),
(241, '64cb69950703a', '14.224.160.12', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36 Edg/115.0.1901.188', 1, 1691052437, 'Chrome', 'Windows'),
(242, '64d091b6611ec', '14.224.160.12', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36 Edg/115.0.1901.188', 1, 1691390390, 'Chrome', 'Windows'),
(243, '64d4fcb32ead7', '223.27.111.153', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36 Edg/115.0.1901.200', 1, 1691679923, 'Chrome', 'Windows'),
(244, '64d9d76a8d941', '14.224.160.12', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36 Edg/115.0.1901.200', 1, 1691998058, 'Chrome', 'Windows'),
(245, '64deeb60a2bb6', '2402:800:63e5:f', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36', 1, 1692330848, 'Chrome', 'Windows'),
(246, '64e6c2cdeb4a9', '14.224.160.12', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36 Edg/115.0.1901.203', 1, 1692844749, 'Chrome', 'Windows'),
(247, '64eb1941d6052', '223.27.111.153', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36 Edg/116.0.1938.54', 1, 1693129025, 'Chrome', 'Windows'),
(248, '64ec5153ad1e1', '14.224.160.12', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36 Edg/116.0.1938.62', 1, 1693208915, 'Chrome', 'Windows'),
(249, '64f83ca087454', '14.224.160.12', 'vi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36 Edg/116.0.1938.69', 1, 1693990048, 'Chrome', 'Windows'),
(250, '655c5cde66819', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1700551902, 'Chrome', 'Windows'),
(251, '655c6b108dc70', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1700555536, 'Chrome', 'Windows'),
(252, '655c6b689f7b8', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36', 1, 1700555624, 'Chrome', 'Windows'),
(253, '659bac63dde29', '::1', 'en', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', 1, 1704701027, 'Chrome', 'Windows');

-- --------------------------------------------------------

--
-- Table structure for table `view_branches`
--

DROP TABLE IF EXISTS `view_branches`;
CREATE TABLE IF NOT EXISTS `view_branches` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `country` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8_unicode_ci,
  `email` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `website` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `twiter` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `facebook` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `likein` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `instagram` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `other` text COLLATE utf8_unicode_ci,
  `image` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `priority` tinyint(4) DEFAULT NULL,
  `show_homepage` tinyint(1) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `view_branches`
--

INSERT INTO `view_branches` (`id`, `name`, `country`, `address`, `email`, `phone`, `website`, `twiter`, `facebook`, `likein`, `instagram`, `other`, `image`, `priority`, `show_homepage`, `date_created`, `user_created`) VALUES
(1, 'Singapore branch', 'Singapore', '8 Eu Tong Sen Street, Office 1, #21-98/99, The Central, Singapore 059818<br />120 Tuas South Avenue 2 West Point Bizhub Singapore 637165', 'enail@gmail.com', '', 'https://sin.com', '', '#', '', '', 'other', 'https://apeironbioenergy.vn/images/posts/_branches/sing.jpg', 0, 1, '2023-02-26 21:18:22', 1),
(2, 'Apeiron Bioenergy (Viet Nam) Company Limited', 'VietNam', 'Kho B&igrave;nh Dương: 18/14 Hai B&agrave; Trưng Nối D&agrave;i, Khu Phố T&acirc;y B, Phường Đ&ocirc;ng H&ograve;a, TP. Dĩ An, tỉnh B&igrave;nh Dương<br /><br />Kho H&agrave; Nội: X&oacute;m 5, Th&ocirc;n Văn Hội, X&atilde; Văn B&igrave;nh, Huyện Thường T&iacute;n, TP. H&agrave; Nội<br /><br />Kho Cần Thơ: Số 32, Tỉnh Lộ 920, Khu Vực Thới Ngươn B, Quận &Ocirc; M&ocirc;n, TP Cần Thơ', '', '', '', '#', '#', '', '', '', 'https://apeironbioenergy.vn/images/posts/_branches/vn.jpg', 1, 1, '2023-02-27 10:36:45', 1),
(3, 'Apeiron Bioenergy Inc.', 'Philippines', 'Level 20-1 One Global Place, 5thAvenue Corner 25th Street, Bonifacio Global City Taguig City', 'abp.enquiry@apeironbioenergy.com', '+63 9503471972', '', '', '#', '', '', '', 'https://apeironbioenergy.vn/images/posts/_branches/thailand2.jpg', 2, 0, '2023-03-17 15:33:23', 1),
(4, 'Apeiron Bioenergy (Thailand) Co., Ltd.', 'Thailand', 'No. 20/68, Village No.5, Khlong Song Sub-district, Khlong Luang District Pathum Thani Province', 'abt.enquiry@apeironbioenergy.com', '+66 212 017 26', '', '', '', '', '', '', '', 3, 0, '2023-05-03 15:11:24', 1),
(5, 'Apeiron Bioenergy Sdn. Bhd.', 'Malaysia', 'No.3, Jalan Tiram Sejahtera 1, Taman Tiram Sejahtera, 81800 Ulu Tiram Johor, Malaysia', 'abmy.enquiry@apeironbioenergy.com', '+60 786 898 12', '', '', '', '', '', '', '', 3, 0, '2023-05-03 15:17:27', 1),
(6, 'PT Apeiron Bioenergy Indonesia', 'Indonesia', 'l. Raya Jakarta Bogor Km 47.3 Nanggewer, Cibinong, Bogor&nbsp;<br />Jawa Barat, Indonesia<br /><strong>PT Apeiron UCO Biodiesel Refinery</strong><br />Jl. Raya Merak Km 116 Depot Gerem Grogol, Kota Cilegon, Banten, Indonesia', 'abi.enquiry@apeironbioenergy.com', '+62 021 875 423 8', '', '', '', '', '', '', '', 3, 0, '2023-05-03 15:19:42', 1),
(7, 'Apeiron Bioenergy L.L.C.', 'United Arab Emirates', 'No. 201, 2nd Floor, Zak Holdings Building,<br />Al Quoz 2 Dubai<br />United Arab Emirates', 'abd.enquiry@apeironbioenergy.com', '+97 144 224 097', '', '', '', '', '', '', '', 3, 0, '2023-05-03 15:20:49', 1),
(8, 'Tanghe Jinhai Biological Technology Co., Ltd.', 'China', 'Gangliu Industrial Park, Tanghe County, Henan Province<br /><strong>Apeiron Jinhai (Sichuan) Bioenergy Co., Ltd.<br /></strong>No. 16 Chenghong Road, Building 1, Unit 1501, No. 8, Chenghua District<br />Chengdu City, Sichuan Province', 'abc.enquiry@apeironbioenergy.com', '+86 028 851 815 00', '', '', '', '', '', '', '', 3, 0, '2023-05-03 15:21:47', 1),
(9, 'Apeiron Bioenergy Japan, Inc.', 'Japan', 'Kojimachi Place 5F<br />2-3-9 Kojimachi Chiyoda Ku<br />Tokyo, Japan', 'abj.enquiry@apeironbioenergy.com', '+65 622 111 65', '', '', '', '', '', '', '', 3, 0, '2023-05-03 15:22:30', 1),
(10, 'Greenfire Bioenergy Co. Ltd.', 'Cambodia', '#133 Lum, Street 2011, Cheang Tong Village<br />Sangkat Krang Thnong, Khan Sen Sok<br />Phnom Penh, Cambodia', 'Greenfire@apeironbioenergy.com', '+855 865 567 86', '', '', '', '', '', '', '', 3, 0, '2023-05-03 15:23:06', 1);

-- --------------------------------------------------------

--
-- Table structure for table `view_carousel`
--

DROP TABLE IF EXISTS `view_carousel`;
CREATE TABLE IF NOT EXISTS `view_carousel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `image` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `title_small` text COLLATE utf8_unicode_ci NOT NULL,
  `title_small_en` text COLLATE utf8_unicode_ci,
  `title_large` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `title_large_en` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `default_button` tinyint(1) DEFAULT NULL,
  `priority` tinyint(4) DEFAULT NULL,
  `link_button1` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `text_button1` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `link_button2` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `text_button2` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `view_carousel`
--

INSERT INTO `view_carousel` (`id`, `image`, `title_small`, `title_small_en`, `title_large`, `title_large_en`, `default_button`, `priority`, `link_button1`, `text_button1`, `link_button2`, `text_button2`, `user_created`, `date_created`) VALUES
(10, 'https://apeironbioenergy.vn/images/posts/_carousel/carousel-3.jpg', 'Dầu Ăn Đã Qua Sử Dụng được chúng tôi thu gom để xuất khẩu và sử dụng làm nguyên liệu để sản xuất dầu diesel sinh học.', 'The wastes we collect are recycled and used as feedstocks for the production of biodiesel and renewable diesel. ', 'Chúng tôi bảo vệ môi trường', 'We protect the environment', 1, 1, '', '', '', '', NULL, NULL),
(11, 'https://apeironbioenergy.vn/images/posts/_carousel/2155d467c6451c1b4554.jpg', 'Chúng tôi hợp tác với các cộng đồng địa phương và thu gom chất thải từ các nhà hàng, khách sạn và nhà sản xuất thực phẩm.', 'We collaborate with local communities and collect wastes from their restaurants, hotels, and food manufacturers. ', 'Chúng tôi tạo ra nhận thức', 'We create awareness', 1, 2, NULL, NULL, NULL, NULL, 1, '2023-02-27 08:39:59'),
(12, 'https://apeironbioenergy.vn/images/posts/_carousel/2155d467c6451c1b4554.jpg', 'Chúng tôi hợp nhất những người thu gom chuyên nghiệp trong lĩnh vực quản lý chất thải để tăng cường thực hành thu gom chất thải tốt nhất, bảo vệ lợi ích cộng đồng và thúc đẩy quản lý môi trường và tính bền vững.', 'We unite professional waste collectors to strengthen the best practice of waste collection, protect industrial interests and promote environmental stewardship and sustainability.', 'Chúng tôi đoàn kết ngành nghề', 'We unite the industry', 1, 3, NULL, NULL, NULL, NULL, 1, '2023-02-27 08:57:13');

-- --------------------------------------------------------

--
-- Table structure for table `view_contact`
--

DROP TABLE IF EXISTS `view_contact`;
CREATE TABLE IF NOT EXISTS `view_contact` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `subject` text COLLATE utf8_unicode_ci,
  `message` text COLLATE utf8_unicode_ci,
  `services` tinyint(11) DEFAULT NULL,
  `viewed` tinyint(1) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `view_contact`
--

INSERT INTO `view_contact` (`id`, `name`, `email`, `phone`, `subject`, `message`, `services`, `viewed`, `date_created`) VALUES
(1, NULL, 'a10@gmail.com', NULL, NULL, NULL, 2, 1, '2023-02-27 22:38:08'),
(2, NULL, 'a10@gmail.com', NULL, NULL, NULL, 2, 1, '2023-02-27 22:38:27'),
(3, 'An nguyen', 'nguyenvantyan@gmail.com', '123456678', 'hello', 'hello you', NULL, 1, '2023-02-28 08:21:57'),
(4, NULL, 'a13@gmail.com', NULL, NULL, NULL, 1, 1, '2023-03-01 09:59:27'),
(5, 'Dinh van vinh ', 'vinh74233@gmail.com', '0901683895', 'Thu gom', 'Tôi muốn làm đại lý thu gom dầu đã qua sử dụng ỏ miền nam cho công ty ', NULL, 1, '2023-06-25 07:16:56'),
(6, 'Đinh văn vinh ', 'vinh74233@gmail.com', '0901683895', 'A', 'Mình ở quận 9 tp hcm có xe xưởng rộng muốn làm đại lý thu và xử lý dầu ăn đã qua sử dụng cho công ty ', NULL, 1, '2023-07-01 13:08:18'),
(7, 'Vinh ', 'vinh74233@gmail.com', '0901683895', 'A', 'Mình ở vòng xoay liên phường quận 9 có kho xưởng rộng và bãi có xe 2.5t muốn hợp tác thu gom dầu ăn đã qua sử dụng ', NULL, 1, '2023-07-01 13:13:44');

-- --------------------------------------------------------

--
-- Table structure for table `view_services`
--

DROP TABLE IF EXISTS `view_services`;
CREATE TABLE IF NOT EXISTS `view_services` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `name_en` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `summary` text COLLATE utf8_unicode_ci,
  `summary_en` text COLLATE utf8_unicode_ci,
  `image` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `link` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `link_en` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `priority` tinyint(4) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `view_services`
--

INSERT INTO `view_services` (`id`, `name`, `name_en`, `summary`, `summary_en`, `image`, `link`, `link_en`, `priority`, `date_created`, `user_created`) VALUES
(1, 'Dầu ăn đã qua sử dụng (UCO)', 'Used Cooking Oil (UCO)', 'Dầu ăn đã qua sử dụng (UCO) là dầu và chất béo đã được sử dụng để nấu ăn. UCO thô trước tiên được tinh chế để đáp ứng các tiêu chuẩn cấp hàng hóa nhất định trước khi được sử dụng làm nguyên liệu cho dầu diesel sinh học. Chứng nhận Carbon & Bền vững Quốc tế (ISCC) được chứng nhận.', 'Used cooking oil (UCO) is the oil and fat that has been used for cooking. Raw UCO is first refined to meet certain commodity-grade standards before being used as feedstocks for biodiesel. International Sustainability & Carbon Certification (ISCC) certified.', 'https://apeironbioenergy.vn/images/posts/_services/service-1.jpg', '', '', 1, '2023-02-26 22:28:45', 1),
(2, 'Mỡ heo ', 'LARD ', '<p>Ch&uacute;ng t&ocirc;i l&agrave; một c&ocirc;ng ty uy t&iacute;n trong lĩnh vực thu mua Mỡ heo từ c&aacute;c đối t&aacute;c l&agrave; c&aacute;c c&ocirc;ng ty v&agrave; nh&agrave; m&aacute;y chế biến. Sản phẩm Mỡ heo l&agrave; một nguồn nguy&ecirc;n liệu c&oacute; gi&aacute; trị, được sử dụng rộng r&atilde;i trong nhiều ng&agrave;nh c&ocirc;ng nghiệp. Ch&uacute;ng t&ocirc;i cam kết tuyệt đối đảm bảo quy tr&igrave;nh thu mua nghi&ecirc;m ngặt, dựa tr&ecirc;n c&aacute;c ti&ecirc;u chuẩn từ c&aacute;c đối t&aacute;c cung cấp. B&ecirc;n cạnh tầm quan trọng về gi&aacute; trị kinh tế, ch&uacute;ng t&ocirc;i cũng coi trọng sự bảo vệ m&ocirc;i trường, đặc biệt l&agrave; trong việc tối ưu h&oacute;a t&agrave;i nguy&ecirc;n v&agrave; giảm thiểu chất thải.</p>', '<p>We are a reputable company in the field of purchasing Lard from suppliers such as companies and processing plants. Lard is a valuable raw material widely used in various industries. We are committed to ensuring a strict procurement process based on international standards. In addition to the economic value, we also prioritize environmental protection, particularly resource optimization and waste reduction.</p>', 'https://apeironbioenergy.vn/images/posts/_services/mo-heo.jpg', '', '', 2, '2023-02-27 09:49:30', 1),
(3, 'Mỡ Cá ', 'Fish oil', 'Mỡ Cá  (Fish oil) là một nguyên liệu sản xuất tại Việt Nam và có sản lượng đứng đầu thế giới\r\n\r\nMỡ Cá chứa nhiệu loại Vitamin,Vi Khoáng , tạo Mùi thơm, dễ bao bọc trong viên thức ăn là nguyên liệu trong sản xuất thức ăn chăn nuôi, gia súc gia cầm và thủy hải sản.\r\n\r\nNgoài ra Mỡ Cá còn dùng để sản xuất dầu nhiên liệu sinh học và dầu nhớt bôi trơn', 'Fish oil is a raw material produced in Vietnam and is the highest output in the world\r\n\r\nFish fat contains many kinds of vitamins, micro-minerals, creates aroma, is easily encapsulated in feed pellets, is a raw material in the production of animal feed, livestock, poultry and seafood.\r\n\r\nIn addition, Fish Fat is also used to produce biofuel oil and lubricating oil.', 'https://apeironbioenergy.vn/images/posts/_services/mo-ca.jpg', '', '', 3, '2023-02-27 09:50:39', 1),
(4, 'Sản phẩm khác', 'Other Products', 'Mỡ động vật là mỡ động vật được sử dụng để sản xuất dầu diesel sinh học. Glycerin thô là sản phẩm phụ trong quy trình sản xuất dầu diesel sinh học được sử dụng trong lĩnh vực thực phẩm và dược phẩm.', 'Tallow is animal fat used for the production of biodiesel. Crude glycerin is a by-product in the biodiesel manufacturing process used in the food and pharmaceutical sector.', 'https://apeironbioenergy.vn/images/posts/_services/service-4.jpg', '', '', 4, '2023-02-27 09:51:25', 1);

-- --------------------------------------------------------

--
-- Table structure for table `view_showcases`
--

DROP TABLE IF EXISTS `view_showcases`;
CREATE TABLE IF NOT EXISTS `view_showcases` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `name_en` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `summary` text COLLATE utf8_unicode_ci,
  `summary_en` text COLLATE utf8_unicode_ci,
  `link_youtube` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `priority` tinyint(4) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `view_showcases`
--

INSERT INTO `view_showcases` (`id`, `name`, `name_en`, `summary`, `summary_en`, `link_youtube`, `image`, `priority`, `date_created`, `user_created`) VALUES
(3, 'Toàn cảnh nhà kho của chi nhánh Bình Dương', 'Overview the warehouse', 'Toàn cảnh nhà kho', 'Overview the warehouse', '//www.youtube.com/embed/jW-DDc7iDf0', 'https://apeironbioenergy.vn/images/posts/_showcases/toancanhnhakho1.jpg', 1, '2023-02-27 10:09:38', 1),
(4, 'Video kho chứa dầu đã qua sử dụng', 'Video of used oil storage', 'sum', 'sum', '//www.youtube.com/embed/uNm2WIzLspc', 'https://apeironbioenergy.vn/images/posts/_showcases/hinhanhkhochua1.jpg', 2, '2023-02-27 10:20:12', 1),
(5, 'Toàn Cảnh kho chứa dầu tại Hà Nội', 'Ha Noi Warehouse', 'Ha Noi Warehouse', 'Ha Noi Warehouse', '//www.youtube.com/embed/LpDafWqSTjM', 'https://apeironbioenergy.vn/images/posts/_showcases/mayloc1.jpg', 3, '2023-02-27 10:24:30', 1),
(6, 'Kho Cần Thơ', 'Can Tho Warehouse', 'Video Kho Cần Thơ tại chi nhánh Apeiron Bioenergy Việt Nam.', 'Video Warehouse Can Tho at Apeiron Bioenergy Vietnam branch.', '//www.youtube.com/embed/FJlckNwKlQM', 'https://apeironbioenergy.vn/images/posts/_showcases/kho-can-tho.jpg', 1, '2023-03-18 13:05:59', 1),
(7, 'Phòng thí nghiệm tại Cần Thơ', 'Laboratory in Can Tho', 'Video Phòng thí nghiệm Cần Thơ tại chi nhánh Apeiron Bioenergy Việt Nam.', 'Video Can Tho Laboratory at Apeiron Bioenergy Vietnam branch.', '//www.youtube.com/embed/QGVsiGuhauM', 'https://apeironbioenergy.vn/images/posts/_showcases/cantho-phongthinghiem.jpg', 1, '2023-03-18 13:13:48', 1),
(8, 'Phòng thí nghiệm tại Bình Dương', 'Binh Duong Laboratory', 'Video Phòng thí nghiệm tại Bình Dương (chi nhánh Apeiron Bioenergy Việt Nam).', 'Video Lab in Binh Duong (Apeiron Bioenergy Vietnam branch).', '//www.youtube.com/embed/eSHTBmgMBl0', 'https://apeironbioenergy.vn/images/posts/_showcases/phongthinghiem-binhduong.jpg', 1, '2023-03-18 13:30:59', 1);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `auth_assignment`
--
ALTER TABLE `auth_assignment`
  ADD CONSTRAINT `auth_assignment_ibfk_1` FOREIGN KEY (`item_name`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `auth_assignment_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `auth_item`
--
ALTER TABLE `auth_item`
  ADD CONSTRAINT `auth_item_ibfk_1` FOREIGN KEY (`rule_name`) REFERENCES `auth_rule` (`name`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_auth_item_group_code` FOREIGN KEY (`group_code`) REFERENCES `auth_item_group` (`code`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `auth_item_child`
--
ALTER TABLE `auth_item_child`
  ADD CONSTRAINT `auth_item_child_ibfk_1` FOREIGN KEY (`parent`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `auth_item_child_ibfk_2` FOREIGN KEY (`child`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `user_visit_log`
--
ALTER TABLE `user_visit_log`
  ADD CONSTRAINT `user_visit_log_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
